# Current Reference Artifacts

These files are included as implementation references, not as substitutes for the Constitution.

- Cycle1_game_rules_reference.zip
- Cycle1_qmo_derivation_reference.zip
- Cycle1_render_pipeline_reference.zip
- Cycle1_locked_playfield_reference.zip

Recovery priority:
Constitution → source mathematics → Cycle Amendment → reference implementation.
