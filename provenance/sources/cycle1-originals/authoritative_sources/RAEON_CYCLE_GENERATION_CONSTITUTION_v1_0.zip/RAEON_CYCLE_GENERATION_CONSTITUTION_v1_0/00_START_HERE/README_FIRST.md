# RAEON CYCLE GENERATION CONSTITUTION v1.0

## Purpose

This ZIP is the authoritative recovery package for reconstructing the raeon card-cycle
generation pipeline.

If the working thread, temporary API, or local development environment is lost, this
package is intended to answer:

1. What source mathematics must be loaded?
2. In what authority order?
3. How is one card Cycle derived?
4. How are 120 Field Generator QMOs created?
5. How are base Local Manifold QMOs created?
6. How are fusion, emergent coupling, and termination relations generated?
7. How is the API closed and validated?
8. How are QMOs converted into render specifications for Blender and Metal?
9. Which choices are game canon versus recovered research mathematics?
10. What must never be silently changed between Cycles?

The package is deliberately procedural. It is not merely documentation.

---

## The one-sentence constitution

**The mathematics is the permission system.**

A raeon move, relationship, fusion, coupling, or derived field is legal only when the
closed raeon API can derive it from its internal mathematical objects and operators.

---

## Minimum recovery inputs

To regenerate a Cycle from first principles, load:

1. Genesis Field corpus
2. Chirality Fabric corpus
3. Propagation Engine corpus
4. This Constitution ZIP

API 4.3 is optional as an architectural precedent, not mathematical authority.

---

## Canonical high-level pipeline

Genesis Field
    ↓
Chirality Fabric
    ↓
Propagation Engine closed recursive family
    ↓
Cycle seed / closed fractal domain
    ↓
2×2×2 Chirality Byte states
    ↓
120 Field Generator QMOs
    ↓
Generator compatibility graph
    ↓
Base Local Manifold QMOs
    ↓
Closed pairwise playing-field graph
    ↓
Fusion QMOs / Emergent Field QMOs / explicit Termination
    ↓
QMO → RenderSpec
    ↓
Blender mesh
    ↓
Swift + Metal runtime animation

---

## Cycle-1 reference constants

Cycle size: 200
Field Generators: 120
Prime Fields: 30
Utilities: 50
Deck size: 60

Base Local Manifold distribution:
- 15 Red / 3 Generator
- 13 Orange / 4 Generator
- 11 Yellow / 5 Generator
- 9 Green / 6 Generator
- 7 Blue / 7 Generator
- 5 Violet / 8 Generator

Total base Local Manifolds: 60

These values are Cycle-1 canon. A future Cycle may deliberately choose a different
distribution, but only through an explicit Cycle Constitution Amendment.

---

## Recovery rule

Never infer missing canon from examples.

If a required mathematical operator is absent:
- mark it OPEN,
- create no legal edge,
- and do not fabricate a result.

If a game-specific operator is introduced to make raeon executable, label it
GAME_CANON and preserve the distinction from recovered external physics.
