import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'api'))
import qmo_api
print(qmo_api.qmo('FG-001'))
print(qmo_api.compatibility('FG-001')[:5])
print([m['definition']['manifold_id'] for m in qmo_api.manifolds_for('FG-001')])
