# RAEON CHIRALITY QMO API v0.2

Executable Cycle-1 QMO graph.

- 120 Field Generator QMOs
- 60 Local Manifold QMOs
- 2482 derived Generator-pair compatibility relations
- SQLite typed dependency graph
- query API
- JSON/CSV exports
- provenance boundary
- tests

The compatibility law is explicitly game-derived v0.2 and can be replaced by exact R62 Chirality Fabric coupling semantics later without renumbering FG-001..FG-120.


# v0.3 Render Production Layer

This package now includes a deterministic QMO -> RenderSpec -> Blender -> Metal pipeline.

New:
- `render/render_spec.py`
- `render/export_render_spec.py`
- 60 generated RenderSpec JSON files
- `blender/build_manifold.py`
- `metal/RaeonRenderSpec.swift`
- `metal/RaeonField.metal`
- formal rendering mathematics
- Blender-to-Metal production guide
- render JSON schema
- render regression tests

The render layer is downstream from the canonical QMO graph.
