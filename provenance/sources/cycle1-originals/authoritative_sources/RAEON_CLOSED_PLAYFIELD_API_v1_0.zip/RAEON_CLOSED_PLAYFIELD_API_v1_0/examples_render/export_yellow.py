import sys, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'render'))
from render_spec import build_render_spec
spec=build_render_spec('M-Y-03')
out=ROOT/'examples_render'/'M-Y-03.render.json'
out.write_text(json.dumps(spec,indent=2))
print(out)
