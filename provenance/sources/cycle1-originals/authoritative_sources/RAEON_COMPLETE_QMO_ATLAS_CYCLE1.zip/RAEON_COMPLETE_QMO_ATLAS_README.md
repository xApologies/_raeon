# raeon Complete QMO Atlas — Cycle 1

This corrects the earlier base-only atlas.

The locked API currently contains:
- 60 base Local Manifold QMOs
- 343 Fusion-Derived Local Manifold QMOs
- 1691 Emergent Field QMOs
- 2094 total render-relevant field/topology QMOs

Files:
- `RAEON_COMPLETE_QMO_ATLAS_CYCLE1.md` — exhaustive human-readable atlas
- `RAEON_COMPLETE_QMO_ATLAS_INDEX.json` — full machine-readable index
- `RAEON_DERIVED_COMBINATION_SUMMARY.md` — support-color/result counts

The earlier 60-base atlas was incomplete for the user's requested purpose.
This package is the complete current closed-QMO atlas.
