# Required Codex completion response
Report: branch/start/end/remote SHA; production package path; Genesis sources; realized topology; exact commands/test counts; acceptance X/X; negative tests; `_bricked` read-only result; OPEN/non-goals; exact Pass-2 entry state; confirmation main untouched. Point to maintained receipt and reproducible ignored evidence. Do not merely say "all tests pass."
