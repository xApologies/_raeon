# Test/build requirements
Inspect current tooling and extend the existing canonical runtime runner rather than creating redundant command families.

Rerun at least:
```text
python -B tools/genesis_runtime.py doctor
python -B tools/genesis_runtime.py dependencies verify
python -B tools/genesis_runtime.py build
python -B tools/genesis_runtime.py verify
python -B tools/genesis_runtime.py test
python -B tools/genesis_runtime.py repository-test
python -B tools/genesis_runtime.py audit
git diff --check
```
Add Pass-1 production RAEON realization/demo tests through this tooling or the repository's current canonical equivalent. Use real Horizon/Hypervisor, never fake integration. Run current repository validators/regressions/gameplay tests as Git currently prescribes. Record actual current counts, not historical expected counts.

Evidence: compiler/build receipts, Pass-1 tests, acceptance mapping, repository validation, branch/head/remote/clean status, upstream read-only check.
