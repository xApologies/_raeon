# Pass-1 canon snapshot — verify against current Git
- Board = stable GEOMETRIC/player; dynamic relational framework.
- Attachments: Deck, Hand, Graveyard, Prime Region, Configuration Region.
- Deck/Hand/Graveyard remain empty in Pass 1; Hand normal capacity 7.
- Three fixed Prime positions/player; do not invent boot Prime cards.
- Permanent universal Configuration Spaces A/B/C; no expansion at boot.
- Configuration Space = persistent State GEOMETRIC, not QMO.
- Screen position != identity. Opponent private contents hidden.
- Nexus mediates State mutation; Rainbow Road is transport.
- Starting hand, draw cadence, mulligan, first-player, phases, refresh, victory and timing remain OPEN.
