# Architecture lock
`GENESIS HORIZON <-> PYTHON HYPERVISOR <-> PLATFORM PORT`.
Horizon: one sea -> one Shell -> one Nexus -> one State.
Chirality Fabric foundational; Rainbow Road sole internal transport.
RAEON is a Genesis application realized in State. Do not redesign these during Pass 1.
