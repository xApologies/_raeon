# Diplomatic Pouch — RAEON Pass 1
Give this ZIP to Codex and say only:
> Execute according to `00_EXECUTE_THIS_FIRST.md` inside the Diplomatic Pouch.

WRITE: `xApologies/_raeon` only. READ-ONLY: `xApologies/_bricked`.
Scope: Roadmap Pass 1 only — production RAEON Genesis application realization and empty two-player match topology in State.
