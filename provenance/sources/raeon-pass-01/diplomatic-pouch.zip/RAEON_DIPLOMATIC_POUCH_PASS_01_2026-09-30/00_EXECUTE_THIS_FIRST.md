# CODEX EXECUTION ORDER — RAEON PASS 1
This is an implementation task, not a planning/summarization task.

## Recover first
From the existing `_raeon` workspace:
1. inspect status/branch/remotes and fetch;
2. preserve newer accepted work;
3. verify audited runtime milestone `71b3a3fbdbce7eece25076a0fd303887cc70d4f1` is in ancestry or identify its accepted successor;
4. read `AGENTS.md`, `development/modules/core-game/GENESIS_RUNTIME_EXECUTION.md`, and every file in this pouch.
Create/continue a dedicated Pass-1 task branch. Do not merge main.

## Build
Create the real production RAEON Genesis application package using the already validated Horizon application-realization contract. It must realize in State:
- one Match;
- exactly two Players;
- one stable Board/player;
- empty Deck, Hand and Graveyard containers/player;
- three fixed Prime positions/player;
- exactly permanent Configuration Spaces A/B/C/player;
- explicit ownership/containment/attachment/visibility relations.

Use real Genesis source compiled/executed by the pinned toolchain. Preserve the existing `horizon-conformance` package as proof infrastructure unless a compatible refactor is required. Python may remain the trusted host binding, but may not replace Genesis realization with a Python-only RAEON graph.

Do NOT implement cards, shuffle/draw, field/QMO resolution, Prime arithmetic, color, turns, combat, victory, UI, animation, Blender or native platform ports.

## Prove
Execute every Pass-1 acceptance case, the existing Genesis runtime tests/audit, current `_raeon` validators/regressions/gameplay specification tests, source-integrity guards, `git diff --check`, and `_bricked` read-only verification.

Create maintained `PASS_01_RECEIPT.md` plus machine-readable receipt in the appropriate development/provenance area. Record exact commands/counts, branch/start/end/remote SHA, negative tests, limitations and Pass-2 entry state. Push the task branch and leave the tree clean. Main remains untouched.
