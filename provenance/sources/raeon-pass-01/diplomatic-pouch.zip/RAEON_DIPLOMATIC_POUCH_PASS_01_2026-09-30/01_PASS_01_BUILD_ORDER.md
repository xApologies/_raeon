# Pass 1 build order — Production RAEON realization

## Existing machine — do not redesign
`GENESIS HORIZON <-> PYTHON HYPERVISOR <-> PLATFORM PORT`.
Horizon = one `sea -> Shell -> Nexus -> State`; Chirality Fabric foundational; Rainbow Road sole internal transport. The Horizon already supports verified `manifest -> admission/integrity -> realize_application -> State successor`.

## Read current Git authority
Before coding read current versions of:
`data/board/genesis-horizon.json`, `design/game/board/SYSTEM.md`,
`data/game/match.json`, `design/game/match/SYSTEM.md`,
`data/topology/configuration-spaces.json`, `data/platform/runtime-direction.json`,
`game/core/genesis_horizon/README.md`, Horizon adapter, and conformance application.
Newer accepted Git authority supersedes this pouch snapshot.

## Production placement/package
Place production RAEON application source under the existing executable `game/` architecture, not `tests/`, without creating a redundant top-level project. Provide a stable/versioned manifest, real `.gen` realization/observation sources as needed, immutable source hashes and declared views. If Horizon allowed roots currently admit only the conformance test package, deliberately add the production RAEON root while keeping arbitrary paths denied.

## Topology
MATCH: one stable Geometric containing/owning two player organizations. Do not invent OPEN match rules.
PLAYERS: exactly two stable semantic roles, independent of screen coordinates.
BOARD: one stable Geometric/player; dynamic relational framework, not a flattened dictionary or alias of children.
BOARD attachment roles: DECK_PORT, HAND_PORT, GRAVEYARD_PORT, PRIME_PORT, CONFIG_PORT. Port/role identity is distinct from attached child.
CONTAINERS: stable empty Deck/Hand/Graveyard/player. Metadata may encode accepted ordered/capacity constraints, but no movement mechanics.
PRIME REGION: exactly three fixed empty positions/player; do not invent Prime card population.
CONFIG REGION: exactly A/B/C/player, permanent universal, persistent GEOMETRIC, initial EMPTY, no expansion spaces. Configuration Space is not QMO.

## Identity/atomicity
All runtime identities unique/stable; coordinates never identity. Relationships explicit/queryable. Realization is one coherent State successor or none. Observe cannot duplicate. Checkpoint/restore/restart preserve semantic topology. Identical package realization follows current idempotent contract; conflicting application rejected.

## Visibility
Define/test owner-private and opponent-public projections sufficient to prove authorized own topology and no hidden opponent/private/native-backend leakage. Views are projections of one State.

## Required negative cases
Unauthorized realization; package/source SHA tamper; path escape; undeclared/malformed source; duplicate/conflicting semantic identity; injected pre-publication failure; application attempt to inherit/mutate machine domains. Every rejection preserves prior semantic root.

## Genesis/toolchain
Topology must be produced by actual Genesis source. Compile twice and prove deterministic bytecode. Do not invent syntax. Do not regenerate QMO/cycle mathematics.

## Headless demonstration
Boot Horizon -> realize production RAEON -> bind both player Hypervisor sessions -> HELLO/SNAPSHOT -> prove empty topology/privacy -> checkpoint -> close/restart/restore -> reconnect -> prove same semantic identities/topology with new boundary epoch -> prove observation alone does not advance game revision.

## Hygiene/exit
Generated evidence stays in established ignored build locations. Maintained source/tests/provenance stay in established repository paths. No caches/venvs/generated ZIPs/copied `_bricked` committed. Pass 1 is complete only when every acceptance case passes, existing gates remain green, remote branch matches local HEAD, worktree clean, main unmerged.
