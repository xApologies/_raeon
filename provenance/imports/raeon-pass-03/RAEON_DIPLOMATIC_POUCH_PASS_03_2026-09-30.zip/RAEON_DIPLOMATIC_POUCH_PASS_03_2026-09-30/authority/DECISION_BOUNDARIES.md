# Canon, engineering decisions and unresolved contracts

Current `_raeon` design/data and accepted decisions govern gameplay. Newer accepted decisions override this dated snapshot. `_bricked` governs the inherited language/Chirality/Road definitions; it does not silently change RAEON gameplay. This pouch authorizes implementing accepted behavior, not changing accepted math because it is easier to code.

## Accepted scope to preserve

- FG copies retain identity, source reference, owner/history through deployment and reconfiguration.
- Configuration Space is live State, not an entry in the QMO corpus.
- Position is XY; orientation is 3D; source-admitted orientation is required for legal links/closure.
- Correct source membership and admitted configuration both matter; count alone never activates a field.
- Ordinary valid 3–8-FG outputs are Red through Violet. Eight is Violet, not automatically White.
- Resolved spaces can reopen; failed closure does not send FGs to Graveyard.
- Individual committed FG extraction is not an ordinary move; whole-space merge is permitted in principle.
- Merge reduces two independent spaces to one and preserves every actual copy; links keep supports distinct.
- Emergent fields require active support, are non-targetable, use zero Configuration Spaces and can coexist on multiple admitted pairs.
- A/B/C are initial permanent provenance. There are at most nine independent spaces with up to six utility-created additions. Merge accounting must not be guessed from the old minimum wording.
- Chirality Fabric and Rainbow Road remain the foundation and transport. Canonical source bytes are not rewritten.

## Engineering decisions Codex may make and test

Module decomposition within current paths; source-index layout; exact deterministic field ID namespace; portable finite numeric encoding; efficient dependency caches; serialization and atomicity implementation; witness representation; deterministic build/recovery. These cannot alter mathematical admissibility, gameplay caps, copy policy or permission.

## Source/policy resolution ledger

`acceptance/SOURCE_POLICY_GATES.json` names the actual unresolved areas observed in source. Search preserved source and current accepted decisions, then either implement the justified mapping or retain a specific gate. An archived membership graph is not automatically a geometric position/orientation witness. A rendering layout is not automatically legality. A broad old “OPEN mathematics” label does not mean the already imported Cycle-1 rules are unusable.

All discretionary new rules require an accepted decision. Generic partial/blocked replies must name the operation, required missing input, files searched, test exposing the gap, and the smallest decision needed. Continue unrelated implementable units. Never count source-readiness metadata as a completed field operation.

## Privacy and offline boundaries

The three Pass-2 projection failures must be fixed in actual inherited code. Ordinary topology observations are filtered by selected view, not just actor capability. Final packaged runtime must not contact/read the original `_bricked` checkout or GitHub, and missing local dependencies fail closed rather than fetch.
