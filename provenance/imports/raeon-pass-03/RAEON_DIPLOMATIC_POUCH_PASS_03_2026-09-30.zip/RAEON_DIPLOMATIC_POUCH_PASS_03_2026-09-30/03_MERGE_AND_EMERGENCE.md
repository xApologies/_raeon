# Whole-space merge, fusion and passive emergence

## 1. Keep two operations distinct

**Merge:** two independently usable Configuration Spaces become one coupled space containing all actual FG copies. The originals cease independent operation. A source-valid topology may be re-resolved in the combined space. This costs board width.

**Link:** two existing active fields remain in their spaces. Their admitted pair relationship may expose one or more specifically source-defined emergent field instances. No space is created or consumed. Multiple valid pairwise links may coexist.

Never implement link as merge or use a QMO generator union to delete actual repeated copies. Never grant a field merely by combining counts.

## 2. Persistent space and capacity invariants

Start with each player's A/B/C, no expansion, and maximum nine independently usable spaces. Existing Pass-2 additions support Red–Violet capacities 3–8 and repeated colors. Preserve that implementation and its tests.

A merge reduces two independent spaces to one. Permanent A/B/C ancestry must remain recoverable, but there is no accepted automatic rule that recreates a consumed base-space slot. The old `permanent_minimum: 3` wording must not silently undo the accepted merge cost. Store original base provenance and current independent membership separately.

The cap of nine spaces is not the maximum FG count per merged space. The ordinary 3–8 field rule also does not define combined container capacity. Merged-capacity ceiling, permanent-base ownership treatment, split/unfusion, expiry and some merge timing are explicitly OPEN in the inspected design. Locate a newer accepted rule first. If unavailable, expose a blocked-policy response and a preview, and test the atomic merge primitive under a declared conformance policy. Such a fixture is not final playable policy and does not satisfy an unqualified production-merge acceptance case.

## 3. Merge request/preview

Input: owner-scoped source space IDs, expected source revisions, trusted operation permission, optional explicitly accepted destination/pose-frame policy version. Require two distinct active independent spaces in the same owner/match; never merge across players or reuse an already-consumed source.

Preview is read-only and records:
- actual source space/card IDs, capacities, base/temporary lineage;
- multiset union of actual copy IDs (no deduplication);
- candidate source topology/fusion records and their source status;
- transformation needed to express both local XY frames in the merged frame;
- active-field/link invalidations and resulting independent-space count;
- exact missing policy or pose evidence, if any.

No automatic rotation, translation, collision resolution or snapped field pose may be invented by preview. If an accepted source mapping supplies a composed pose witness, it must be checked for all participating copies. Otherwise the merged space is configuring, not automatically a field.

## 4. Atomic merge algorithm

```text
verify owner, two distinct current spaces, permission and policy version
verify capacity/accounting and pose-frame rules are supplied
stage one result space identity (or documented continuing identity)
stage union of all original copy memberships and lineage
transport memberships using existing admitted State-local Rainbow Road units
invalidate old field activations and incident emergents
retire independent membership of both source spaces
attach the result to the same persistent Configuration Region
verify card conservation, region width/capacity and relationship consistency
requery candidate topology and admit a field only with current complete evidence
publish space/card/field/link/history changes together
```

Rejection at any step preserves both original spaces, card locations, capacities, field eligibility, links, native identities/history and semantic root. Do not copy then forget originals. Replay of one committed request must not consume a third space.

## 5. Catalog fusion interpretation

The catalog's `FUSE` result may specify the union of generator **definitions**, not a union of live copy identities. Reconcile both views. For example, two spaces may contain separate copies referencing the same FG definition; those copies must survive. A valid source pair is not permission to collapse the copies to a set or to fit an eight-definition template by deleting an extra ninth instance.

Query the existing pair table for `a_manifold`/`b_manifold` and resolve the actual referenced derived record. Use the type/operator/support fields to validate it. Missing or out-of-domain derived support pairs remain OPEN/NOT_APPLICABLE as supplied. Do not assume every derived field may itself fuse again when the table covers base pairs only.

## 6. Link operation and emergent instances

Input: two distinct live field-instance IDs, owning match/player scope and expected support revisions. Verify both are currently active under valid closure; use their source QMO IDs for catalog lookup but their instance IDs for the runtime link. A disabled/consumed/configuring support cannot provide an active emergent.

An admitted link retains both fields and spaces. Runtime identity includes the canonicalized pair of support instance IDs and the actual emergent QMO ID. Pair canonicalization must follow source symmetry; preserve direction where the source relation is directed. Prevent duplicates from reversed equivalent requests. Several runtime pairs may realize the same emergent QMO without aliasing.

Create only source-defined results with a real support witness. `E` consumes **zero** Configuration Spaces, is not independently targetable, is not a card, and never enters Deck/Hand/Graveyard. It has a source color/rank and activation state, but no color production/tap cadence is introduced here. Future attacks cannot target it directly; Pass 3 exposes/validates this structural constraint without implementing combat.

## 7. Dependency tracking and invalidation

Maintain explicit support-instance references and reverse dependency indexes inside State or a reproducible derived index. On relevant pose/member/closure/merge/support changes, reevaluate affected links and remove/deactivate unsupported emergents in the same committed visible successor. No intermediate snapshot may show color availability from a field that lost its required support.

For A/B/C with valid AB, AC and BC:
- there are three pairwise emergents and still three source spaces;
- losing A invalidates AB and AC;
- BC remains when B and C still satisfy their source relation.

This is a conditional example, not a claim that arbitrary A/B/C QMO choices are all valid. The test must find and record an actual supported triple. If the production catalog has no such triple, test the general dependency algorithm with a clearly isolated fixture and separately report the actual data limitation; do not invent production catalog entries.

Reopening a source field invalidates its old witness even when its QMO identity will later match again. Preserve history and use explicit activation generations/support revisions. Reactivation requires rechecking supports. Do not reset mutable current field color or future READY/USED state through reorientation/linking; exact color-carryover across a topology change is a policy boundary for Pass 4 if not already specified.

## 8. Permission and timing

Deriving consistency consequences from a committed change does not establish a new reaction scheduler. Maintain graph consistency atomically while leaving when a player may request merge/link/unlink under accepted gameplay permission. Use the trusted conformance capability pattern already present for tests where scheduling is not yet available. Grants are scope-bound and never client assertions of legality.

No new voluntary unlink, split, temporary-expiry, combat destruction or recursive emergent-of-emergent mechanic is inferred. Support loss may be exercised by actual admitted reconfiguration, merge or an explicitly labelled internal test action rather than inventing a player attack.
