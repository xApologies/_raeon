# Diplomatic Pouch 03 | RAEON
## Configuration, field topology, merge and emergence

Prepared: 2026-09-30. Type: executable work order for Codex, **not implemented game code**.

**Write destination:** `xApologies/_raeon` only. **Read-only dependency:** `xApologies/_bricked`.

Give Codex this archive after the current Pass-2 correction finishes, then say:

> Execute according to `00_EXECUTE_THIS_FIRST.md` inside this Diplomatic Pouch. Continue from the corrected Pass-2 commit; do not restart the project.

The starting prompt is inside the archive. The work is bounded: turn deployed FG copies into configurable, corpus-backed fields; implement source-supported whole-space merge and passive pairwise emergence. Reuse the real Genesis application, Horizon, Hypervisor, collection transactions, Road and recovery machinery already in `_raeon`.

### Read order

1. `00_EXECUTE_THIS_FIRST.md` — task, recovery, entry gate and working sequence.
2. `01_PASS_03_BUILD_ORDER.md` — code destinations, work units and deliverables.
3. `02_STATE_POSE_AND_QMO.md` — identity, geometry, query and resolution contracts.
4. `03_MERGE_AND_EMERGENCE.md` — distinct merge/link operations and support dependencies.
5. `04_GENESIS_AND_TRANSACTIONS.md` — implementation boundaries and atomicity.
6. `05_PRIVACY_AND_PRESENTATION.md` — corrected privacy contract and renderer-neutral cues.
7. `06_ACCEPTANCE_AND_SCENARIOS.md` and `acceptance/` — independent exit criteria.
8. `07_OFFLINE_BUILD_AND_DELIVERY.md` — reproducible package/build/run isolation.
9. `08_GIT_AND_CONTINUITY.md` — durable progress and later-thread recovery.

`authority/SOURCE_MAP.json` contains concrete source paths, inspected ranges, known Git blob hashes and evidence limits. It does not pretend that large files whose body was unavailable were read. `execution/WORK_QUEUE.json` is the ordered work queue. `continuity/CURRENT_STATE.json` records the privacy correction as pending verification, not passed.

### Before running

The last inspected Pass-2 branch head is `8a20961b97b0bbb6e2e257d3c3ff62992ea6d839`. It contains the reported Pass-2 implementation **before** the privacy correction. It is a recovery anchor, not the correct starting commit by itself. Pass 3 must inherit the actual correction and pass its tests. Do not race the task currently writing those files.

This pouch deliberately contains no whole compiler copy, placeholder game implementation, generated QMO corpus or artificial padding. The source repository is the development landscape; the pouch is the instruction/acceptance/continuity package.
