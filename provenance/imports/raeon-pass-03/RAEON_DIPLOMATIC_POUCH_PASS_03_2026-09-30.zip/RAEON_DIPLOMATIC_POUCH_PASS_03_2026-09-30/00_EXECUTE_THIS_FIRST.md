# CODEX EXECUTION ORDER — RAEON PASS 3

You are implementing Roadmap Pass 3 in the existing RAEON project. Do not respond with another plan, a synopsis or an illustrative scaffold. Produce tested source and recovery records in `_raeon`, then reproducible distributions. Continue ordinary implementation/test corrections without seeking approval for each internal step.

## 1. Recover the correct working state before editing

Read applicable AGENTS.md, PROJECT_CONSTITUTION.md, DEVELOPMENT_CONSTITUTION.md, CONTRIBUTING.md, `development/PIPELINE.md`, existing runtime/Pass-1/Pass-2 execution records, the latest privacy-correction record, and this pouch. Work only in `xApologies/_raeon`. `_bricked` is read-only; never edit its tracked files or create commits there.

Inspect working tree, current branch, recent commits and remotes. Fetch using existing authorized credentials. Preserve other work; do not reset, clean, force-checkout or overwrite uncommitted changes. The earlier milestones are:

- runtime: `71b3a3fbdbce7eece25076a0fd303887cc70d4f1`;
- Pass 1: `23ebfc3be3a4e6ae4883793bfc99b1dbfae67bf8`;
- pre-correction Pass 2: `8a20961b97b0bbb6e2e257d3c3ff62992ea6d839` on `codex/raeon-pass-02`.

Discover and record `PASS2_CORRECTED_SHA` from actual Git. Verify its ancestry or documented accepted replacement. A different SHA alone is not proof of a fix. Require the three projection regressions described below to pass using the current real application/Horizon/Hypervisor. Preserve both ordinary owner/opponent controls and the new public-view cases.

1. Public view remains public even when the actor also has private access.
2. Public view does not receive that actor's recent private inspection.
3. Later projection stages do not reintroduce filtered `private_to` relations.

If the correction task is still writing, or its commit/tests are unavailable, leave `WAITING_FOR_PASS_02_PRIVACY` in the execution record and stop before modifying shared implementation. Do not fix it independently while another task is fixing it. After it has completed, continue on `codex/raeon-pass-03` (or the repository-approved equivalent) descended from the corrected state. Never start from outdated `main` just because it is the default branch. Do not merge main.

## 2. Frozen design

`GENESIS HORIZON <-> PYTHON HYPERVISOR <-> PLATFORM PORT` remains three objects.
Horizon contains exactly one `sea -> Shell -> Nexus -> State`. Chirality Fabric is foundational throughout. Rainbow Road is the one admitted information/card/relationship transport. RAEON is the application within State. Do not create another VM, bus, domain or object called Configuration Frontier.

Pass 2 already supplies native card copies, ordered collections, grants for conformance scenarios, dynamic Configuration Spaces and recovery. Extend these, do not replace them. Each player starts with A/B/C, can have six additional spaces and at most nine independently usable spaces. A merge may reduce the independent count; do not restore deleted width automatically or reinterpret permanent provenance as an always-three-active-space assertion.

## 3. Implement this pass

Execute `execution/WORK_QUEUE.json` in order:
- source/pose-capability recovery and corpus lock;
- QMO-backed deployed FG view and typed XY/3D pose operations;
- live partial relationships and two-gate field resolution;
- reopening/reconfiguration and stale-result invalidation;
- whole-space merge and source-backed fusion;
- support-preserving links and passive emergent fields;
- corrected private/public projections and non-authoritative feedback;
- real end-to-end tests, nonempty checkpoint/replay, offline packaging and receipt.

Read the actual source before choosing a pose/contact rule. Recover a runtime mapping from the imported algorithms, compatibility tables, source archives and approved Genesis authorities. A source note saying OPEN is a locator for work, not permission to give up or bypass it. Implement deterministic derivations when fully justified and record the derivation. When a policy genuinely requires a new accepted choice, record its exact missing contract and fail closed for that operation; continue independent work. Do not silently create physics, redefine the catalog or count a gated refusal as a successful field realization.

## 4. Non-goals

Do not implement Prime H/C arithmetic, color spending, attack/defense scheduling, refresh timing, utility play windows/costs, victory, native GUI/ports, Blender meshes, animations or shaders. Supply renderer-neutral topology/pose/provenance data only. Do not regenerate the 120 FG definitions or 2,094-object atlas. No bootstrap/network fetch is allowed when running a packaged distribution.

## 5. Completion and recovery

Use the existing runtime runner and development gates. Preserve and run the previous suites, including the corrected privacy tests. Compile/verify/execute every claimed supported Genesis handler. Tests must exercise the actual machine, not just text names, dictionaries called fields or preaccepted test witnesses.

Every requirement in `acceptance/PASS_03_ACCEPTANCE.json` needs a result and actual evidence. No changing the denominator, marking blocked positive behavior PASS, fabricating execution receipts or calling all Gates GOLD. A data-mapping conflict may yield an honest partial delivery but must be listed, with implemented work saved and the smallest next action. Source-linked accepted behavior is the target, not perpetual gate documentation.

Commit coherent progress to `_raeon`, push the authorized task branch, confirm remote SHA and clean state, and leave main unmerged. Final receipt must identify `PASS2_CORRECTED_SHA`, Pass-3 implementation/receipt/remote SHAs, source and ABI versions, commands, results, source-preservation and offline evidence, blockers, and the Pass-4 entry state. Complete source and tests matter; file size is not an acceptance test.
