# Local dependencies, build commands and self-contained distribution

## 1. No GitHub dependency during packaged execution

`_bricked` is a read-only development source. The packaged host-reference build must resolve Genesis, Chirality Fabric, Rainbow Road and all QMO inputs actually consumed by Pass 3 locally from the supplied bundle. Neither startup nor a new topology query may clone/fetch/read an external checkout. A source URL in a provenance record is allowed; attempting to access it at runtime is not.

The current developer distribution still declares Windows x64 CPython 3.12 as a prerequisite. Do not claim a signed native iOS/Android/Windows app or bundled interpreter has been delivered. Do not change that supported-host claim merely because a Linux file-validation script works in chat.

## 2. Data packaging delta from Pass 2

Pass 2 did not need the full field/closure catalog at runtime. Pass 3 must explicitly enumerate and include the actual closure/candidate/support/index sources it reads. Use `data/manifests/cycle1-source-import.json` for logical dataset locations and source mapping; include selected exact catalogs or a proven lossless derived index plus declared source verification. No dependency named in a manifest without available bytes and a successful local read.

Expected inputs to examine include FG objects/compatibility, base/fusion/emergent/derived records, atlas, pair table, SQLite, source closure/pose mapping algorithms and any RenderSpec used for supported mapping. Do not package multiple unnecessary representations blindly; whichever is authoritative or used for rebuild/tests must be included. Read-only SQLite queries must not silently write journals into canonical data. Preserve source hashes and notices.

## 3. Extend the established task runner

Inspect `python -B tools/genesis_runtime.py --help` and current implementations. These baseline commands already existed at the anchor; run their current equivalents:

```text
python -B tools/genesis_runtime.py doctor
python -B tools/genesis_runtime.py dependencies verify
python -B tools/genesis_runtime.py build
python -B tools/genesis_runtime.py verify
python -B tools/genesis_runtime.py dialect-test
python -B tools/genesis_runtime.py demo --headless
python -B tools/genesis_runtime.py demo --headless --application raeon
python -B tools/genesis_runtime.py demo --headless --application raeon --scenario cards
python -B tools/genesis_runtime.py test
python -B tools/genesis_runtime.py repository-test
python -B tools/genesis_runtime.py package
python -B tools/genesis_runtime.py verify-distributions
python -B tools/genesis_runtime.py audit
git diff --check
```

Add a documented Pass-3 topology scenario to the same runner, for example `demo --headless --application raeon --scenario topology`; this option is a **required implementation target**, not a claim it already exists. Add catalog verification and Pass-3 acceptance aggregation through the existing structure. Discover new .gen/import/data dependencies rather than relying on the old 36-source list.

## 4. Cold verification

Build from one clean committed implementation revision. Extract both updated distributions into a fresh path containing spaces, clear upstream and development-path environment overrides, and use the packaged dependencies. Keep the original checkouts inaccessible; deny/monitor DNS, connection attempts, Git/shell child processes and external reads using the prior trusted-reference isolation harness. Verify the interceptor with independent denial probes before reporting isolation.

Recompile deterministically, run the old cards demo and new topology scenario, issue queries not already warmed in a cache, restart from a nonempty checkpoint and compare identities/results. Move aside one **temporary extraction copy** of an essential QMO/pose/dependency file and verify that startup/query fails explicitly without a fetch/fallback. Restore the test copy afterward. Never sabotage the user's source checkout as an isolation test.

Packaged originals remain unchanged. Exact file manifests cover every payload and exclude themselves intentionally. Hash after removing caches. No Git metadata, secrets, virtualenv, scratch logs or machine-specific paths are shipped as application source. Artifact metadata may document the build environment, but runtime resolution must not require it.

## 5. Delivery

Maintain source, tests, locks and concise receipts in Git. Generated archives/evidence belong in the established ignored build area or approved release storage. Produce matching Horizon/RAEON and Hypervisor distributions; an unchanged fence still needs a compatible paired-version record. Do not vendor the multi-gigabyte language corpus merely to enlarge a ZIP.

Final evidence states commands, exit codes, exact source/mapping/ABI versions, runtime test scope, reported versus independently reproduced results, bundle sizes/hashes, and explicit interpreter/native-port prerequisites. Offline success is a tested property, not the absence of the word `_bricked` from source comments.
