# Pass 3 build order

## A. Outcome

An owner can rearrange already-deployed FG copies inside their Configuration Space. The runtime reads the preserved FG/QMO corpus, distinguishes candidate compatibility from currently admitted pose relationships, and activates a catalog-backed field only when both membership and configuration pass. Whole-space merge combines actual copies; a link leaves supports distinct and may expose a passive emergent field. Changes preserve identities, respect the corrected projection scope, survive restart, and use the existing transaction/Rainbow Road path.

## B. Existing sources and intended homes

Use these existing homes, adjusting names only to match newer accepted repository structure. Suggested new basenames are tasks, not claims that those files already exist.

| Existing home | Add or extend here |
|---|---|
| `game/core/raeon/application/` | Manifest, imports/hashes, Genesis operation sources such as `set_fg_pose.gen`, `query_configuration.gen`, `resolve_configuration.gen`, `merge_spaces.gen`, `link_fields.gen`, and topology observation. Use genuine supported composition rather than requiring one file per table row. |
| `game/sandbox/` | State contracts for deployed copies, poses, membership revisions, active field reference and merge accounting. |
| `game/qmo/` | Read-only lookup/index contracts and implementations needed by Genesis; lossless source-derived indexes and witness verification, not a newly generated mathematical corpus. |
| `game/manifolds/` | Local/fusion field and emergent support lifetimes; importable Genesis modules where supported. |
| `game/core/genesis_horizon/bindings/python/src/raeon_genesis_horizon/` | Only necessary generic host-reference value/query/transaction/binding support. Version changes; preserve source execution and ownership boundaries. |
| `platform/shared/python_hypervisor/` | Keep the fence game-agnostic. Add transport encoding support only if current schemas cannot express a declared portable pose/query value. Do not move topology rules here. |
| `tests/integration/genesis_horizon/` | Real Pass-3 application tests, corrected-privacy integration, regression fixtures and restart tests. |
| `tools/genesis_runtime.py` and existing helpers | Discover/build every new source, run demos/tests, assemble/verify distributions and report pass status. |
| `development/modules/core-game/` | One `PASS_03_EXECUTION.md`, one machine progress record, maintained receipt and small source/policy-gate record. |
| `provenance/decisions/` | Exact compatibility/source amendment and original-pouch hash; preserve historical locks. |

No duplicate top-level `engine`, `runtime`, `game_v2` or standalone second project. Existing tests may retain exact historical fixtures, but production behavior must point to one current application.

## C. Ordered units and exit products

**W00 — Corrected entry.** Establish privacy-fixed ancestor and clean/isolated task workspace. Baseline current runtime and Pass-1/2 suites. Save the exact starting SHA before edits. No write-racing.

**W01 — Source and mathematical-admission map.** Hydrate referenced catalogs/archives locally, hash them, recover operator definitions and source mappings, build read-only indexes. Produce `TOPOLOGY_SOURCE_LOCK` and a compact capability report distinguishing available mathematical rules, deterministic runtime derivations and unresolved policy. Include meaningful old source guards before implementation changes.

**W02 — Deployed FG and pose state.** Bind each actual card copy to its immutable FG record, not a generic template posing as its final geometry. Preserve ID/history while adding a QMO-backed face/occupancy view and versioned pose. Define typed finite XY and 3D orientation encoding. No new card object for deployment. This unit includes a real parameterized Genesis path and negative input/admission tests.

**W03 — Read-only query and partial edges.** Implement complete finite catalog candidate lookup and live facing-edge checks. Expose why membership/pose is unresolved without turning queries into mutations. Bound search and return explicit incomplete/budget outcomes. No edge is fabricated because two colors match.

**W04 — Resolve, reopen, invalidate.** Create distinct runtime field identities through Genesis when witness checks succeed. Bind native/max color to QMO, and track mutable output separately. Reorientation/member change invalidates obsolete closure and incident emergents in the same logical successor. Re-observe/re-resolve does not duplicate identities or heal/tap-reset fields.

**W05 — Merge and fusion.** Implement preview and atomic authorized merge with exact copy-union, finite admission, explicit pose-frame treatment and the accepted two-to-one width cost. Requery against source fusion results; no card deduplication, invented combined capacity or automatic base-space replenishment. Keep unknown policy cases blocked without blocking verified lookups and independent contracts.

**W06 — Pairwise links/emergence.** Evaluate explicit support pairs using the catalog. Preserve two supporting fields, add zero Configuration Spaces, maintain stable relation-backed emergents and invalidate only affected support edges. No recursive emergent source type without authority. Relation-check cadence stays separate from consistency maintenance and color-production timing.

**W07 — Public/private topology readout.** Integrate dynamic objects with selected-view filtering. New fields, pose feedback, links, explanations and requests cannot expose hidden hands, decks, inventories, inspections or native paths. Transport remains the existing byte contract. Data is ready for later rendering, not a graphics build.

**W08 — Real compound scenarios.** Execute valid base closures, incorrect poses/families, reopening, merge and emergent support changes through the actual Hypervisor/Horizon, and persist a nonempty scene. A toy graph-only fixture may be a unit oracle, never the evidence for the playable mapping.

**W09 — Distribution, receipt, continuation.** Package exactly the now-required local QMO/runtime/data slice; cold rebuild/run with no source checkouts/network/Git. Update the pass receipt and continuity from executed evidence. Source locks and prior tests remain protected. Commit/push, do not merge main.

## D. Proportional implementation

Use one reusable set of mechanics over the data. Do not produce a bespoke handler per FG, manifold or support pair. Retain data-driven definitions, explicit types, short documented modules and actual behavioral tests. Keep compilation, mathematical outcome, gameplay permission and display feedback separate so failures are intelligible.
