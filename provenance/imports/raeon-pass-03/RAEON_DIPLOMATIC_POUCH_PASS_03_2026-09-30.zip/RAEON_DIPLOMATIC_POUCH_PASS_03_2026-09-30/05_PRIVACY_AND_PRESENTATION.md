# Selected-view privacy and future presentation

## 1. Pass-2 correction is an entry dependency

Carry forward the actual fixed projection implementation and its regressions, not only its receipt. The historical audit is included under `continuity/PASS_02_PRIVACY_AUDIT.md` for context. Its failing excerpts are historical evidence, not replacements for the fixed source or a patch to execute again.

The effective disclosure rule is the intersection of the requested view, trusted actor permissions, live object's visibility and operation-specific scope. An actor's ability to request a private view does not make their public view private. Every appended collection/field/link/inspection object must pass the same policy as objects in the original projection.

Pass-3 operations may not broaden the scope implicitly:
- public with a private-capable actor still contains no private Hand data;
- public and opponent views receive no private inspection results;
- filtered `private_to` relations cannot be added back by a topology merge stage;
- a new field or edge may expose only already-authorized deployed objects and evidence;
- public `can_resolve`, candidate lists, missing-generator hints and query errors cannot reveal the opponent's hidden deck/hand inventory;
- public events, receipts, digests and cached hints do not embed private raw state, source machine paths or native receipt identifiers.

## 2. New projection records

Expose enough information for a later renderer without implementing that renderer now:

- space ID, owner, independent/merged status, capacity contract and EMPTY/CONFIGURING/RESOLVED;
- authorized deployed FG copy IDs, source display keys, declared XY/3D pose and revision;
- admitted visible partial-edge endpoints and source face identifiers;
- field instance/QMO identity, native color, visible current status and witness revision;
- link/emergent identity, visible support instance references and non-targetability;
- available operation/rejection reason only within the actor's admitted scope.

Do not export whole QMO databases per frame. The installed read-only corpus can support source-authorized visuals later; current snapshots/deltas carry the necessary bounded values and references. Existing projection version semantics and stale/reconnect recovery remain in force.

## 3. Preview is not authority

The future Port may preview a drag or interpolation locally; only admitted State pose is committed. Hints/tethers are readouts of the current authorized relationship evaluation. Distinguish candidate/catalog compatibility from current admitted facing. A soft line, snap or particle cannot create legality.

No orbit camera or player-controlled position Z is added. The approved interaction is fixed top-down XY positioning plus 3D rotation. Blender/RenderSpecs/shaders/meshes/touch tuning are not Pass-3 implementation deliverables. This pass prepares their data contract.

## 4. Cache and view tests

Test both players and an actor owning private access while explicitly selecting public. Query before and after a private inspection. Exercise public→private→public reconnects and changed view/session epochs. Do not share cached hinted completions across incompatible view contexts. Test newly-created spaces/fields/links, not only the 37 original boot objects.

When a support vanishes, the public projection must lose its emergent at the same visible revision. Unrelated hidden state changes need not create observable private side channels. Document legitimate public count/topology changes instead of accidentally broadcasting global internal roots.
