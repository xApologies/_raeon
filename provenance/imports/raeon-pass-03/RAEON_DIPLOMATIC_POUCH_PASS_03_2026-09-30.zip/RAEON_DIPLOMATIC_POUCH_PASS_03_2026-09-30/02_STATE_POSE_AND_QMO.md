# State, deployed FG, pose and QMO contracts

## 1. Three authorities that must not be confused

1. **Immutable source definition:** original FG, manifold, fusion, emergent or pair record and its supplied status. Read-only. Preserve its original address, field names, labels and hash.
2. **Live application state:** actual copy identities, membership, XY/3D pose, active relationships, field instance, support references, and transaction revision in State.
3. **Admission evidence:** reproducible demonstration that the live state satisfies the chosen source definition plus the accepted runtime mapping. A matching catalog row alone is not a current geometric witness.

The Configuration Space is the live host for the second category, not a member of the finite QMO corpus. Its new pose/query support must not generate replacement FG or manifold definitions.

## 2. Source recovery must precede a geometry rule

At the preparation pin, the imported base record `M-R-01` names `FG-001`, `FG-044`, `FG-117` and a connected/cycle-bearing compatibility subgraph. It does not in that record supply every required XY position and 3D orientation. The accepted interaction document explicitly calls the exact runtime pose mapping OPEN. Therefore:

- inspect supplied closure algorithms and source mappings, not only this sample;
- inspect the full face-compatibility records, local/derived definitions, RenderSpecs, archived game algorithms, and approved Genesis geometric operations;
- recover A–H indexing, face winding, face correspondence, rotation conventions, locality/contact criteria and admissible transformations from those authorities;
- keep `rotation_class` as a source field; it is not automatically a complete list of player orientations;
- do not infer a color from population count, rebuild the cube occupancy from an assumed bit order, or accept faces merely because their printed colors agree;
- do not introduce a square grid, contact distance, 24-rotation restriction, reflection, scale-invariance, snapping tolerance or circle/diamond template without source/accepted mapping support;
- matching each pair in isolation does not prove that all pair constraints can be satisfied simultaneously by one pose assignment.

A deterministic derived runtime mapping is allowed when the inputs and logical derivation are complete and independently checked. Store its version, authority paths/hashes, derivation and verification tests as runtime interpretation, not a newly discovered or rewritten QMO. A discretionary missing rule remains explicit. Search the relevant preserved archive via its manifest before declaring the source absent; never regenerate the corpus to fill a gap.

**Boundary test:** a configuration with the correct generator identities but a known wrong admitted orientation must not resolve. It is not enough to implement a membership query and label it a pose solver.

## 3. Runtime identity/data model

These are implementation records, not newly invented Genesis syntax. Bind them through supported Genesis source and the versioned reference ABI.

| Record | Minimum semantic content |
|---|---|
| Deployed FG view | Persistent card-copy ID; catalog/QMO address+hash; owner; containing space ID; occupancy/void; six source faces/color views; source rotation/parity; pose and pose revision. Native version may change, card identity does not. |
| Configuration state | Persistent space and region IDs; ordered/defined member IDs; membership revision; per-copy poses; source-derived capacity contract; lifecycle EMPTY/CONFIGURING/RESOLVED; active field instance ID or null; query/witness revision. |
| Pose | Declared coordinate frame and numeric schema; finite x,y; an explicit 3D rotation representation; encoding precision; pose revision. No player-controlled position z. |
| Live partial edge | Two distinct copy IDs; local face IDs; transformed face correspondence; source compatibility record locator; live-pose witness/status; dependency revisions. |
| Runtime field | New persistent field-instance ID, distinct from the space and QMO address; source QMO ID+hash; support copy IDs; witness; native/max color; current output/lifecycle state; active generation eligibility reserved for Pass 4. |
| Query result | Membership outcome, pose/closure outcome, permission outcome; candidates; selected/verified witness if any; dependency stamp; exact reason/source; complete/partial search status. |

The mutable field state must not be overwritten every time the catalog is queried. A source QMO may have many runtime field instances; neither should be used as the identity of the other. Same-owner duplicated card definitions remain distinct copies. Two different players can realize the same topology without sharing state.

## 4. Numeric and orientation contract

The existing byte profile uses exact integers and rejects arbitrary floats. Do not slip floating NaN/Infinity or unversioned JSON floats into it. Choose a documented finite value encoding compatible with the actual Genesis value layer (for example explicit scaled-integer components or canonical encoded rotation parameters); declare units/scale/frame and validate every boundary. A schema extension requires a version and round-trip tests on both sides.

Represent a genuine 3D orientation, not just a 2D yaw or a field color. Define row/column/quaternion/Euler ordering if used, composition order, handedness, normalization, and canonical equivalence. Ordinary rotation must not mutate source chirality/parity by treating a reflection as a rotation. Numeric canonicalization may remove equivalent encodings; it may not authorize new legal poses. Distinguish encoding precision from gameplay snap/neighbor tolerance. Final continuous-looking gestures and magnetic animation are later UI work.

Validate the entire requested pose before changing State: finite bounded values, correct owner, actual deployed FG copy, current space membership, expected revision, declared schema, admitted frame/orientation. Reject ambiguous or malformed transforms atomically. An accepted placement can still produce an unresolved field; that is different from a malformed request being rejected.

## 5. Required operations and ownership

Use the following semantic interface, adapting names to the supported language and current application conventions. Every mutating operation needs trusted authority and expected-State/space revision. These are work-order names, not preexisting Genesis keywords.

**Describe deployed FG:** look up one authorized deployed copy and return its QMO-backed orientation/face view, never its hidden source-deck contents. No new copy and no mutation.

**Set FG pose / set bounded pose batch:** update XY and 3D orientation for copies already in the same authorized space. A batch is all-or-none. Do not permit extraction into another space. Use the actual Genesis handler/value layer; derive stale-field and incident-edge invalidations as part of the same committed successor. Return admitted pose and dependency revisions. Preserve untouched copies and all card history.

**Query configuration:** inspect committed members and poses, retrieve the full finite relevant candidate set, and verify what can be verified. Read-only: no source changes, no activation, no healing, no tap refresh and no request-caused semantic revision change. Bound candidate search; budget exhaustion is not proof of no match.

**Resolve configuration:** recompute or verify the query's witness against current State, source lock, mapping and authority. Do not trust a client-supplied `VALID`, graph, source hash or target color. On success create/update one runtime field activation for this space according to accepted identity rules, with QMO-defined native/max color. Publish field, witness, space pointer, support/link consequences and receipt together. Repeated identical request returns the original result. Repeated unchanged resolution is not duplicate field creation.

**Reconfigure/reopen:** operate within the persistent space; keep committed cards and their identities. Adding a member or changing an admitted pose makes old closure evidence stale. If the new organization is nonempty and not currently proven, expose CONFIGURING. Failed closure does not auto-retire cards. Resolve again only with current evidence.

## 6. Deterministic resolution algorithm

```text
capture authorized space ID + membership/pose revisions
load source-pinned definitions for its actual FG copies
validate workspace and type/owner/capacity invariants
form a multiset of source identities, preserving each copy ID
query catalog indexes for candidate existing topology records
for each candidate within budget:
    match required membership using source multiplicity rules
    verify current XY/orientations using the accepted runtime mapping
    verify compatible live face edges in one simultaneous configuration
    check the source-backed closure predicate on those live edges
    retain witness and exact dependency/source/mapping versions
return separate outcomes and candidate evidence
on requested realization:
    recheck all dependencies and gameplay authority at commit
    publish one coherent successor or none
```

Count-to-color mapping is applied only to a **valid ordinary** topology: 3/4/5/6/7/8 correspond to Red/Orange/Yellow/Green/Blue/Violet. The source QMO remains the color authority. Eight cards do not imply White. Do not infer a White manifold, a Black FG, special White substitution, or a fusion capacity rule from this ordinary mapping.

If several valid catalog records remain, preserve the candidate ambiguity and use an existing accepted selection rule. Deterministic sort order is appropriate for displaying candidates, not permission to choose a different topology silently. If whole-space versus subset resolution or leftover-copy handling is unspecified, report the specific gate rather than discarding extra cards or treating them as absent.

## 7. Outcomes are not a Boolean

Preserve original source statuses `VALID`, `TERMINATES`, `NOT_APPLICABLE`, `OPEN`, `UNTESTED` and provenance labels such as `GAME_DERIVED_v0_2`. A source import being validated is not runtime proof.

Expose separate fields such as:
- `catalog_status`: original row status or missing-record OPEN;
- `membership`: MATCH / NO_MATCH / UNRESOLVED;
- `pose_closure`: ADMITTED / NOT_ADMITTED / UNRESOLVED / BUDGET_EXHAUSTED;
- `permission`: ADMITTED / DENIED / POLICY_GATED;
- `effect`: OBSERVED / COMMITTED / REJECTED;
- `complete_search`: true/false with bounded continuation information when applicable.

Names may align with existing schemas, but these meanings must survive. Missing source and exhausted search never become mathematical TERMINATES. One FG cannot form an ordinary field. Two may have legal partial edges without closure. A compatible catalog graph with incompatible current orientation is still not a live field.

## 8. Witness and cache contract

A witness contains source lock/digests, mapping and ABI version, space and actual copy IDs, membership/pose revisions, candidate topology, derived edge correspondence, closure evidence and declared solver bounds. Reconstruct it independently from current state; a hash of an assertion is not proof of that assertion.

Cache keys include all source/mapping/dependency revisions and authorization scope where needed. A change of pose, member, space, source version, view or branch invalidates incompatible results. A witness computed before a merge or checkpoint-epoch transition cannot authorize a later mutation without revalidation. Query caching is not a second authority store.

## 9. Source data coverage

Index all preserved relevant records, not a handpicked demo-only subset. Expected historical counts: 120 FGs; 60 base; 343 fusion; 1,691 emergent; 2,094 atlas; 1,770 base pairs; 2,482 compatibility pairs. Reconcile newer accepted data before enforcing counts. Distinguish data coverage from runtime-pose coverage. Cross-check original SQLite and JSON where both are used without rewriting the originals.

The full atlas excludes the FG objects and seed. Original QMO addresses must remain stable. Keep large exact source integers such as RenderSpec seeds out of lossy number conversions. Partial field/edge presentation must not enumerate the opponent's unseen card inventory.
