# Acceptance evidence and independent scenarios

`acceptance/PASS_03_ACCEPTANCE.json` is a specification. Every initial result is NOT_RUN. Tests and receipts are separate output, bound to exact source/ABI/data versions. Do not edit the original requirements into an apparent successful result file.

## Evidence classes

- **SOURCE:** inspected source hash/path/schema/status; does not itself prove executable behavior.
- **BUILD:** actual supported parser/compiler/verifier receipts and deterministic output hashes.
- **BEHAVIOR:** expected versus actual values from a real Genesis/Horizon application path, including negative cases.
- **INTEGRATION:** byte input/output through the real Hypervisor and corrected player/public projections.
- **DISTRIBUTION:** cold extraction, dependency availability, denied external sources/network/Git, rebuild/run/recovery.
- **GIT:** actual source commit, remote verification, starting/corrected ancestry and preserved authorities.

A test fixture oracle can be Python without putting game implementation in Python. At least the main success/negative scenarios must execute real .gen handlers and native operations. Do not count mocks, source string searches, emitted status labels or a PING response as topology integration.

## Independent oracle requirements

Select representative existing records using an independent read-only oracle, record exact IDs and hashes, and preserve their original statuses. Do not compute expected results by calling the same resolver used by the implementation under test. For closure, verify live edge/pose constraints independently of the runtime's `VALID` flag. For support loss, inspect concrete link/field/space identities and dependencies.

The source candidate `M-R-01` and the source fusion pair `M-O-01` + `M-O-02` are concrete lookup anchors in `fixtures/SCENARIO_RECIPES.json`. They are not claimed to carry a complete pose witness in this pouch. Find/derive a source-supported simultaneous pose and record it before treating either as a live success case.

## Required headless progression

1. Boot and realize the current RAEON package, not only the historical conformance app.
2. Initialize source-valid inventories under the existing test-only grants, then deploy actual copies using Pass-2 operations. No direct mutation to preconstruct the successful topology.
3. Observe unresolved one/two-FG partial relationships and a wrong-pose candidate.
4. Change admitted poses through the real byte intent path; resolve an actual source-backed field.
5. Change a supporting pose/member and prove old closure is invalidated without losing cards.
6. Test source-supported merge and passive pairwise links, including a valid multiple-link scenario and selective support loss. Exercise declared policy refusal separately.
7. Preserve the same active scene through checkpoint, shutdown, fresh process restore and reconnect; compare semantic identities/poses/links and privacy, not host timestamps.
8. Cold package run without original repository checkouts or network access.

## Result rules

Required positive behaviors remain BLOCKED when a source or policy is missing. The negative test that safely refuses that case may PASS separately. No denominator shrinking, changing blocked required positive tests to NOT_APPLICABLE, or using a handcrafted fixture's success to claim the production mapping is finished.

Run all independent work even if one policy remains blocked. Report two separate dimensions: source/record coverage and executable pose/merge/emergent behavior coverage. Full Pass-3 completion requires all mandatory acceptance cases supported by current accepted semantics to pass and no unresolved mandatory positive branch. If this cannot be established, preserve a PARTIAL/BLOCKED checkpoint with exact next actions rather than a false clean sign-off.

A baseline failure is not automatically a Pass-3 regression. Record the pre-change result and change evidence. Existing accepted fixes must not be reverted to make new tests pass. Historical tests retain their intent; add explicit version-migration tests where the application ABI changes.
