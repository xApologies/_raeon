# Resume RAEON — Diplomatic Pouch 03

The current workflow is chat-directed package handoff → Codex implementation in `_raeon` → pushed commit and evidence → review → next pass. Chat is not canonical code storage.

Start by reading `CURRENT_STATE.json`, `00_EXECUTE_THIS_FIRST.md`, the source map and latest Git execution/receipt. Pass 2 was implemented, then three selected-view privacy defects were found. The user has a Codex correction task running. Do not label it passed from this dated package; locate and verify its final commit and real integration tests.

Use only `_raeon` as a write destination. Inherit corrected Pass 2, keep `_bricked` read-only and pinned, preserve old tests/data and the three-object architecture. Pass 3 is the configurable FG/field/merge/emergence layer. Pass 4 is the Prime/color/turn layer. No animation or native-port implementation belongs in this pouch.

Continuation prompt:

> Astraeus, continue RAEON Pass 3 from this Diplomatic Pouch and the latest receipt. Recover current `_raeon` Git state and the Pass-2 privacy fix first. Resume at the recorded work unit; do not reconstruct the project or regenerate the QMO corpus.
