# RAEON Codex Roadmap — Passes 1–4
Date: 2026-09-30
Authority: continuity/build roadmap; newer accepted `_raeon` Git authority supersedes stale snapshots.

## Development model
Canonical implementation repository: `xApologies/_raeon`.
Read-only upstream: `xApologies/_bricked`.
Git is the development landscape. Codex writes tested implementation directly into `_raeon`.

Validated machine foundation:
`GENESIS HORIZON <-> PYTHON HYPERVISOR <-> PLATFORM PORT`

Horizon singleton profile:
`sea D9–11 -> Shell D7–8 -> Nexus D6 -> State D5 / 3+1+1`.
Chirality Fabric is foundational. Rainbow Road is the one internal transport.
RAEON is a Genesis application admitted/realized in State.

Audited runtime branch/head at roadmap creation:
`codex/genesis-horizon-hypervisor`
`71b3a3fbdbce7eece25076a0fd303887cc70d4f1`

## Global laws
1. Write only to `_raeon`; `_bricked` is read-only upstream.
2. Inspect current Git before editing; preserve newer accepted work.
3. GEOMETRIC is the runtime primitive; card copies preserve stable identity.
4. Genesis implements mechanics; canonical QMO/data define content.
5. Never regenerate the 120 FG corpus or 2,094-object atlas.
6. Rainbow Road remains the sole transport; all authoritative mutation is State-owned and Nexus-mediated.
7. Preserve privacy/visibility at projections.
8. Every pass requires implementation, negative tests, integration, provenance, reproducible commands, coherent commit and authorized push.
9. Do not promote the whole game to COMPLETE/GOLD because one pass completes.
10. If blocked, commit/preserve valid work and record exact blocker/next action.

## Passes
**Pass 1 — RAEON Realization / Empty Match:** production RAEON package; Match, two Players/Boards, containers, Prime positions, three initial Configuration Spaces per player.

**Pass 2 — Card Identity / Containers / Movement:** deck construction, card-copy identities, deterministic shuffle/draw, Hand, Graveyard, legal transfers, ownership/capacity.

**Pass 3 — Configuration Space / QMO Resolution / Fields:** FG placement, XY + 3D orientation, corpus-driven resolution, active fields, merge, pairwise emergence.

**Pass 4 — Primes / Color / Turn Authority:** H/C Prime state, Restore/Degrade/Universal, READY/USED fields, color movement, ACTIVE/DEFENSE authority, complete supported headless gameplay path.

## Continuation protocol
At the end of each pass create/update a pass receipt with branch, start/end/remote SHA, implementation, tests, limitations and exact next step. Update `continuity/CURRENT_STATE.json`.

In a new chat: upload this ZIP plus the latest pass receipt and say **“Continue RAEON at Pass N.”** The assistant must inspect current `_raeon` Git before preparing the next Codex handoff; do not reconstruct architecture from memory when Git has newer authority.
