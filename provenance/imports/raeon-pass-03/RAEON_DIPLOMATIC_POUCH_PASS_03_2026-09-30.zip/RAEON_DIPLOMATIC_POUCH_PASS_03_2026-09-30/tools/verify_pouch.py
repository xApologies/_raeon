"""Verify this instruction pouch's inventory and internal references, not the game.

Uses only the Python standard library; no network, Git access or code execution
from the payload. Run after reviewing this file: python -B tools/verify_pouch.py.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys


def load(root: Path, name: str):
    return json.loads((root / name).read_text(encoding="utf-8"))


def verify(root: Path) -> dict:
    root = root.resolve()
    manifest = load(root, "MANIFEST.json")
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    expected = set(manifest["files"]) | {"MANIFEST.json"}
    if actual != expected:
        raise ValueError(f"inventory mismatch: missing={sorted(expected-actual)}, extra={sorted(actual-expected)}")
    for name, entry in manifest["files"].items():
        posix = PurePosixPath(name)
        if posix.is_absolute() or ".." in posix.parts or "\\" in name or ":" in name:
            raise ValueError(f"unsafe path: {name}")
        target = root / name
        if target.is_symlink() or not target.resolve().is_relative_to(root):
            raise ValueError(f"unsafe target: {name}")
        data = target.read_bytes()
        if len(data) != entry["bytes"] or hashlib.sha256(data).hexdigest() != entry["sha256"]:
            raise ValueError(f"integrity mismatch: {name}")
        if name.endswith(".json"):
            json.loads(data.decode("utf-8"))
        if "__pycache__" in posix.parts or name.endswith((".pyc", ".pyo")):
            raise ValueError(f"cache in pouch: {name}")
    spec = load(root, "acceptance/PASS_03_ACCEPTANCE.json")
    case_ids = {c["id"] for c in spec["cases"]}
    if len(case_ids) != len(spec["cases"]) or len(case_ids) != spec["required_cases"]:
        raise ValueError("acceptance IDs/count mismatch")
    sources = {s["id"] for s in load(root,"authority/SOURCE_MAP.json")["sources"]}
    scenarios = {s["id"] for s in load(root,"fixtures/SCENARIO_RECIPES.json")["scenarios"]}
    gates = {g["id"] for g in load(root,"acceptance/SOURCE_POLICY_GATES.json")["gates"]}
    queue = load(root,"execution/WORK_QUEUE.json")["units"]
    units = {u["id"] for u in queue}
    covered = []
    for u in queue:
        if set(u["depends_on"]) - units:
            raise ValueError("unknown work dependency")
        covered.extend(u["acceptance_ids"])
        if set(u["acceptance_ids"]) != {c["id"] for c in spec["cases"] if c["work_unit"] == u["id"]}:
            raise ValueError("work-unit/case mismatch")
    if len(covered) != len(case_ids) or set(covered) != case_ids:
        raise ValueError("acceptance coverage mismatch")
    for c in spec["cases"]:
        if c["status"] != "NOT_RUN" or c["evidence"]:
            raise ValueError("pouch must not preclaim implementation test results")
        if c["work_unit"] not in units or c["setup_scenario"] not in scenarios:
            raise ValueError("case references unknown unit/scenario")
        if set(c["source_refs"]) - sources:
            raise ValueError("case references unknown source")
        if c["source_or_policy_gate"] is not None and c["source_or_policy_gate"] not in gates:
            raise ValueError("case references unknown gate")
    pouch = load(root,"POUCH.json")
    state = load(root,"continuity/CURRENT_STATE.json")
    if pouch["acceptance_cases"] != len(case_ids) or pouch["work_units"] != len(units):
        raise ValueError("descriptor totals mismatch")
    if pouch["implementation_included"] or state["pass2_corrected_sha"] is not None:
        raise ValueError("instruction-only/correction status changed")
    return {"status":"PASS", "scope":"instruction-pouch integrity and reference consistency only",
            "payload_files":len(manifest["files"]), "total_files":len(actual),
            "work_units":len(units), "acceptance_requirements":len(case_ids),
            "implementation_tests_executed":0}


if __name__ == "__main__":
    try:
        root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
        print(json.dumps(verify(root), indent=2))
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(f"POUCH VALIDATION FAILED: {exc}", file=sys.stderr)
        raise SystemExit(1)
