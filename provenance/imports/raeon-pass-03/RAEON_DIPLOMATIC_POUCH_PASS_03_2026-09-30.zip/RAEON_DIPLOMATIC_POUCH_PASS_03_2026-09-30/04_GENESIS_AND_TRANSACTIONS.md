# Genesis execution, application bindings and transactions

## 1. Reuse the executed system

The repository's host-reference implementation has real graph-profile `.gen` sources and separate value/control-profile entry points. Keep those entry points explicit. Do not change a version header to concatenate incompatible grammars. Source release 1.0 and individual source-profile versions are different concepts.

Pass 2 added `state-collections-v1`, typed arguments, candidate collection state and trusted conformance grants. Its source handlers declare bounded effect policy; generic Python bindings execute reference operations and call native Genesis units. This distinction must remain inspectable. Python reference support is not permission to hard-code per-QMO game behavior in the Hypervisor or replace Genesis with a private Python engine.

## 2. Required extension map

Before implementation record the exact capabilities supplied by current source:

| Need | Inspect/extend |
|---|---|
| Portable pose values | Current envelope schema/strict validation, manifest operation arguments and actual Genesis value/control interpreter. |
| FG hydration | Source catalog's FG record/commitment; current `Collections.definition()` uses a generic representation template and is not a finished QMO-specific pose realization by itself. |
| Dynamic spaces | Existing `ADD_CONFIGURATION_SPACE` and collection memberships/capacities; preserve non-static region behavior. |
| QMO lookup and witness | Source-pinned read-only native query binding callable from declared Genesis handlers; distinguish record retrieval from semantic admission. |
| Configuration lifecycle | Genesis operations staged under the current transaction; change the Pass-2 projection rule that currently maps every nonempty configuration to CONFIGURING so it reads the actual Pass-3 lifecycle instead of overwriting RESOLVED. |
| Live fields/links | Versioned typed State records and native Geometric/relation creation where appropriate, with identity and history. |
| Transaction rollback | Add poses, witnesses, fields, support indexes and grants to the candidate root/checkpoint ABI, not a side dictionary outside rollback. |
| View projection | Reuse corrected selected-view authorization; dynamic new objects pass the same policy. |

These are task-local adapter/application ABI additions. Frozen upstream source remains pinned. A new syntax or upstream semantic operation requires explicit compatibility provenance and tests, not hidden invention. Do not stop at saying a capability is missing when the supplied language can already express it through supported functions/control/relationship operations.

## 3. Backend contract, not ceremonial Genesis

For each meaningful behavior identify: `.gen` source and exports; parser/compiler entry point; source-declared effects; native or generic service called; authoritative values changed; tests proving that handler semantics matter.

Verification must include omission/tamper tests: replacing or removing the pose/resolution/merge/link handler, changing required predicates, omitting Road closure or using an unauthorized source must reject or change the asserted outcome. A wrapper that only emits a receipt while unrelated Python code secretly resolves fields is not completion.

Read-only source data may be decoded/indexed in Python; deterministic algorithms may use the existing reference backend where the language contract delegates them. Document exactly where the mathematical rule is declared and enforced. No claim of full self-hosting or native-device certification is required for this pass.

## 4. General operation envelope

Retain the existing trusted session/application binding, request ID, expected revision, schema version, arguments and correlated result. Add per-space/support revision preconditions where needed. The Port submits intent only. It cannot supply owner, privilege, a trusted witness or the resulting state.

A conformance grant may authorize invoking an operation in tests; it must not replace the actual membership/pose/capacity/closure checks. Production play-timing authority is separate. Do not expose a global admin endpoint or a `force_valid` parameter to players.

## 5. Atomic successor content

A mutating operation stages and publishes, together:

- all affected card/space identities and native versions;
- memberships and local pose revisions;
- verified current edges and closure witness;
- field activation and support-link state;
- dependent emergent invalidation;
- history, grant consumption, outcomes and projection dependency stamps.

Requests, failed proposals and presentation effects are not committed game truth. Include every changed authoritative value in the semantic root and recovery schema. A semantic change must be observable through the actual versioned State path. Card/QMO sources remain immutable.

## 6. Failure matrix

**Before publication:** restore old logical values, native bindings, collections, pending graph, witnesses, reverse indexes, grant status and semantic root. Candidate native files may be reclaimed or retained as unreachable audit history according to existing policy; never treat them as current members. Account for failed attempts against bounded storage so retries cannot exhaust space invisibly.

**After publication, delivery fails:** preserve committed outcome and return it on identical retry. Do not execute a second merge, rotate twice, re-create an emergent or falsely call the completed operation rejected.

**Concurrent stale pose/merge:** serialize through the owner path or reject revision conflict. Two commands against the same base may not both overwrite one another silently.

**Partial search/time budget:** return incomplete/unresolved evidence, not INVALID/TERMINATES. Never mutate merely to finish a query.

**Shutdown/checkpoint:** quiesce to a consistent graph; a restored scene contains no dangling field/support references and cannot re-use stale grants or view cursors across epochs.

## 7. Limits and determinism

Reuse finite budgets for payloads, operations, poses per request, solver steps, candidates, graph edges, native resources, queue length, cache entries, history and storage. Bound hint search as well as accepted mutations. Do not impose new gameplay capacities solely to satisfy a test budget.

Same declared inputs, source/mapping versions and semantic seed produce the same game outcome and canonical witness, independent of filesystem location, dictionary order, renderer frame timing, process PID or transport UUID. Audit timestamps remain outside semantic state. Cache order cannot select the winner among unresolved topology candidates.
