# Git execution and later-thread continuity

## Working branch

Use the actual completed privacy correction as the Pass-3 parent. The original Pass-2 SHA in this pouch is an ancestry/reference anchor only. Capture the correction commit and evidence before edits. If another agent owns the same workspace, coordinate or stop; do not solve conflicts by overwriting its files. A separate worktree alone does not make an unfinished fix a usable dependency.

All writes/branches/commits target `_raeon`. Upstream reads use existing approved dependency locks; never change `_bricked` in place. Do not start a separate Genesis repository or move the language out of `_bricked` in this pass. Main is unchanged until separately authorized merge/review.

## Minimal maintained records

Reuse the existing module development landscape. Keep one execution record, one structured progress/evidence map, one small source/policy-gate record and one closing pass receipt. Add a pointer in applicable AGENTS.md. Avoid one new document per minor edit. The complete chat does not belong in AGENTS.md.

Record after each coherent unit:
- working branch and source commit;
- next exact command or failing test;
- source/mapping versions and current blocking decision;
- implementation and requirement IDs touched;
- last actual test results and remote-push state.

Save source as you work; do not hold it in one enormous generation script until final packaging. Commit coherent work including honest WIP labels. Push permitted task-branch progress. Local save, local commit and successful remote push are different states.

## Source protection

Preserve original FG/QMO source bytes and historic provenance. Update only the new source/amendment records for newly compiled code and runtime indexes; never rewrite historical hashes to make new outputs look old. Keep current application manifest references coherent. Retain old Pass-1/2 fixtures only as historical tests, not duplicate production sources.

## Final status

`READY_FOR_PASS_04` requires verified Pass-3 exit, not just a plan or a test label. Gate/result bookkeeping distinguishes:
- BLOCKED_ENTRY: privacy correction not verified;
- IMPLEMENTING: work running;
- PARTIAL: source saved, some required behavior unproved or gated;
- SOFTWARE_SCOPE_COMPLETE: mandatory supported-host source/behavior/integration/distribution requirements satisfied;
- whole-game PREPRODUCTION remains unchanged.

A receipt file cannot contain its own final commit hash. Record the implementation commit in it, then verify the closing receipt/remote commit in generated evidence or a subsequent query. Never fake a self-referential SHA. Report native-device tests NOT_RUN rather than PASS.

## Next-thread handoff

Upload this pouch and the latest Pass-3 receipt. Say: “Continue RAEON at Pass 3 from the recorded corrected branch; inspect current Git first.” The next assistant reads current state, privacy gate, source map and last exact command before preparing or reviewing a Codex task. If implementation is complete, proceed to Pass 4 with the actual field/pose/support schemas and remaining policy gates. Do not reexplain the whole game or restart the Horizon architecture.
