# Pass 3B implementation note

Consume this contract as NEW runtime-realization authority without modifying source QMO records.

Codex must:
1. load the 60 frozen labeled witnesses;
2. implement best-fit SE(2) shape scoring and hysteretic soft capture;
3. derive allowed face-pair choices for each required edge from the existing compatibility corpus;
4. solve/validate simultaneous orientation closure against current quaternion states;
5. snap only after shape + orientation closure;
6. instantiate the live field QMO/state and finish the blocked Pass-3 cases;
7. preserve the Pass-2 privacy correction and all prior tests;
8. fail closed if a witness cannot be simultaneously oriented—do not alter source mathematics.
