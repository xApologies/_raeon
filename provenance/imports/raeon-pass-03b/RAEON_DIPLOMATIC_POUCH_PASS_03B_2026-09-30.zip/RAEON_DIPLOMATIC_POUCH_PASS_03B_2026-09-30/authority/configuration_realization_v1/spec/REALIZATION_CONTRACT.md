# RAEON Configuration Realization Contract v1.0

## Decision
The imported QMO corpus defines **which FG identities belong to a field and which generator pairs are mathematically compatible**. This contract defines the missing video-game realization layer: how that field is arranged in a fluid two-dimensional Configuration Space.

It does **not** alter the 120 Field Generator QMOs, 60 base manifold identities, compatibility records, Chirality Fabric, or the 2,094-object atlas.

## 2D occupancy
A deployed FG has continuous `(x,y)` position. There is no player-controlled positional Z. Each base manifold has one canonical labeled witness stored in `BASE_MANIFOLD_WITNESSES.json`.

Witness coordinates are normalized axial/triangular coordinates converted to 2D by:

`x = q + r/2`, `y = sqrt(3) r / 2`.

The player does not have to place an FG at exact coordinates. Current positions are compared with the labeled witness after best-fit **translation + global planar rotation**. Reflection is not allowed because it would silently reverse chirality. Game scale is fixed by the FG footprint and is not a state degree of freedom.

## Shape families
The 60 base manifolds deliberately use varied occupancy families: linear bands, triads, chevrons, rhombi, zigzags, houses, stairs, arcs, hex rings, bands, center/ring organizations, arrows, rings and clusters. Shape is therefore not inferred from color or count alone.

A three-generator field may be linear. For linear/extended organizations, the cycle-closing relationship may be a visible coherence tether rather than literal footprint-to-footprint contact.

## Required closure graph
Every base witness has a deterministic Hamiltonian cycle over its actual FG identities. Every edge was checked against the imported compatibility graph. This gives the runtime the minimal connected, cycle-bearing closure graph already required by the source game profile.

Extra compatible pairs are not discarded; they may drive secondary tethers/feedback, but they are not required to resolve this witness.

## Soft snapping
Movement remains fluid. The resolver progresses:

`FREE -> CANDIDATE -> MAGNETIZED -> LOCKED`

Recommended normalized thresholds:
- candidate RMS <= 0.22 and every slot <= 0.35;
- magnetic capture RMS <= 0.14 and every slot <= 0.22;
- release hysteresis when any locked slot exceeds 0.48.

When capture occurs, presentation springs/magnetizes the objects toward the exact canonical relative geometry. **Final LOCKED/RESOLVED requires both the 2D shape gate and the 3D orientation/face-compatibility gate.** Shape alone never activates a field.

## Orientation
Pass 3 already stores canonical 3D orientation. For every required witness edge, Pass 3B must select/validate one of the face-pair matches already supplied by `data/qmo/generators/compatibility.json`, and all required edges must be simultaneously satisfied by the current FG orientations.

No replacement bit law or invented face compatibility is permitted.

## Failure
Correct cards + wrong shape = CONFIGURING.
Correct cards + correct shape + wrong orientation = CONFIGURING.
No valid QMO membership = CONFIGURING.
Failure does not automatically send committed FGs to Graveyard.

## Merge/emergence
This corpus covers the 60 **base** field witnesses. Merge/fusion preserves FG instances and resolves against the existing derived QMO/pair data; emergence remains a relation among distinct resolved supports. Neither operation is permitted to rewrite these base witnesses.
