# EXECUTE THIS FIRST — RAEON PASS 3B
Implementation handoff, not planning.

Writable: `xApologies/_raeon` only. `_bricked` read-only.
Pass-3 remote head at pouch creation: `codex/raeon-pass-03` @ `33f4139719c5b4af83610dcb9600be594a50e78c`.
Inspect remote first; if it advanced, audit and inherit newer valid work. Create/continue `codex/raeon-pass-03b`. Do not merge main.

Mission: install audited Configuration Realization authority and turn Pass 3 into genuine live field resolution with soft 2D snap, source-linked 3D orientation, deterministic fusion, and passive emergence.

Hard laws: no source QMO regeneration; shape and orientation are distinct; labeled SE(2) only; no reflection/scale; no fake board-bearing=cube-normal requirement; source rotation_class uses frozen table; compatibility only from source data; face matches are field relations, not consumable sockets; count never closes; LOCK atomic; State authoritative; Rainbow Road required; Hypervisor game-agnostic; privacy fix retained; no runtime `_bricked`; positive tests require positive execution; whole-game PREPRODUCTION.

Run `VERIFY_POUCH.py` first.
