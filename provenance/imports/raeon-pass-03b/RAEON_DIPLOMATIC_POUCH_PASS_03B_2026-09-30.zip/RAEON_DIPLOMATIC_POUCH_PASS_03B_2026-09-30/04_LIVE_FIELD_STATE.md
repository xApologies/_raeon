# Live field state
Logical progression: EMPTY -> CONFIGURING -> CANDIDATE -> MAGNETIZED -> RESOLVED. Candidate/magnetized may be topology substates.
Positive resolution requires exact membership, complete query, shape capture, all orientation captures, all source edges, fresh revisions, Road closure and atomic publication. Result references the existing LocalManifoldQMO. REOPEN preserves cards and invalidates old closure. Locked fields do not drift; manipulation reopens first. Failure remains CONFIGURING with no Graveyard penalty.
