from pathlib import Path
import json,hashlib,sys
root=Path(__file__).resolve().parent
m=json.loads((root/"MANIFEST.json").read_text())
bad=[]
for rel,rec in m["files"].items():
 p=root/rel
 if not p.is_file(): bad.append(rel+":missing");continue
 if p.stat().st_size!=rec["bytes"]: bad.append(rel+":size")
 if hashlib.sha256(p.read_bytes()).hexdigest()!=rec["sha256"]: bad.append(rel+":hash")
a=json.loads((root/"acceptance/PASS_03B_ACCEPTANCE.json").read_text())
w=json.loads((root/"authority/configuration_realization_v1/data/BASE_MANIFOLD_WITNESSES.json").read_text())
r=json.loads((root/"authority/ROTATION_CLASS_TABLE.json").read_text())
b=json.loads((root/"acceptance/BLOCKED_PASS3_TARGETS.json").read_text())
if len(a["cases"])!=85 or a["required_cases"]!=85 or any(x["status"]!="NOT_RUN" for x in a["cases"]): bad.append("acceptance")
if w["count"]!=60 or len(w["witnesses"])!=60: bad.append("witnesses")
if len(r["classes"])!=24 or [x["rotation_class"] for x in r["classes"]]!=list(range(24)): bad.append("rotations")
if b["count"]!=49 or len(b["ids"])!=49: bad.append("blocked")
if bad:
 print("FAIL",*bad,sep="\n");sys.exit(1)
print("PASS")
print("payload_files",len(m["files"]))
print("acceptance_cases",len(a["cases"]))
print("base_witnesses",len(w["witnesses"]))
print("rotation_classes",len(r["classes"]))
print("prior_blocked_targets",len(b["ids"]))
