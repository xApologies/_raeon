# 3D math
Source `rotation_class` spans 0..23. Frozen runtime mapping is `ROTATION_CLASS_TABLE.json`.
`Q_target_i(phi)=Q_yaw_z(phi)*Q_class[rotation_class(FG_i)]`.
`delta=2 acos(|dot(normalize(q),normalize(target))|)`.
Thresholds are in `ORIENTATION_REALIZATION_V1.json`.
2D witness defines relation topology; 3D orientation defines chirality state in a shared field frame. Do not require board bearing to equal cube face normal. Each required edge must have supplied compatibility/face-signature evidence. Live edge = required witness edge + source compatibility + both endpoint orientation captures. All required edges must be live simultaneously before closure.
