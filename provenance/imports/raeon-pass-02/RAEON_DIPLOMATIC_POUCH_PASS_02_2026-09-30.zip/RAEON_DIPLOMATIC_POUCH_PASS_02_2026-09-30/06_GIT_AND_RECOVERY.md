# Execute in `_raeon`; keep progress recoverable

## Branch discipline

Read actual status before switching/fetching. Do not delete/reset/overwrite another task's
work. The Pass-1 observed branch is `codex/raeon-pass-01` at
`23ebfc3be3a4e6ae4883793bfc99b1dbfae67bf8`; use its newer accepted successor if present.
`main` may still predate the runtime. Record the resolved base before continuing/creating
`codex/raeon-pass-02`. Only this task branch may be pushed under the established workflow.
Do not merge main, force-push, delete another branch or modify `_bricked`.

Read repository constitutions/module gates. This pouch authorizes the Pass-2 implementation
scope and necessary compatible application-binding work; it does not promote unrelated
gates, waive existing integrity checks or authorize a new game rule.

## Recoverable work, not paperwork

One current execution record under the existing core-game development module contains:
resolved paths/dependencies; current P2-W unit; actual last successful/failing command;
exact next action; source SHA and any blocker. Link it from existing AGENTS.md without
replacing established instructions. Persist source as work proceeds. Commit coherent
working units; do not wait to build a giant ZIP before saving code.

A local commit is not remote persistence. Push authorized task commits and verify the
remote SHA. Never use a sandbox/chat file as evidence that Git contains it. Where remote
push is unavailable, preserve the local commit and state that limitation precisely.

## Commands

The following are inspected existing entry points, to be rerun or compatibly extended:

```text
python -B tools/genesis_runtime.py doctor
python -B tools/genesis_runtime.py dependencies verify
python -B tools/genesis_runtime.py dialect-test
python -B tools/genesis_runtime.py build
python -B tools/genesis_runtime.py verify
python -B tools/genesis_runtime.py demo --headless
python -B tools/genesis_runtime.py demo --headless --application raeon
python -B tools/genesis_runtime.py test
python -B tools/genesis_runtime.py repository-test
python -B tools/genesis_runtime.py package
python -B tools/genesis_runtime.py verify-distributions
python -B tools/genesis_runtime.py audit
git diff --check
```

Add a discoverable Pass-2 selector/scenario/test path under the same runner (the exact
new CLI spelling is an implementation choice and must be documented/tested). Keep the
empty Pass-1 scenario explicitly invocable; do not silently replace every old test with
a populated board. Record actual current test counts, not copied historical totals.

When reused native/compiler code changes, rerun relevant upstream suites. Preserve
current game-definition, QMO, normalization, continuity and source-integrity validators.
Do not rerun upstream tests through the original `_bricked` working tree if they write
output; use the isolated dependency copy.

## Completing the pass

The maintained receipt records the implementation commit and the final remote ref. Do
not attempt to embed a commit's own SHA in its content; resolve the closing receipt commit
externally and record it in generated remote evidence. Distinguish committed source from
ignored reproducible logs/distributions. Register new maintained files in current
inventories and amend source guards only for explicitly reviewed new source bytes.

Return implemented locations, `.gen` handler names, generic adapter deltas, actual tests,
mandatory case X/Y, policy-gated items, isolation evidence, matching archive hashes and
Pass-3 entry condition. Keep the entire project PREPRODUCTION unless separately approved.

All later-pass timing/graphics/card-art questions remain out of scope. Continue normal
coding and test corrections without seeking approval after every unit. Stop for missing
access, source/semantic contradictions or a genuinely unsupported requirement, preserving
code and the exact reproducer. Label partial evidence honestly rather than weakening tests.
