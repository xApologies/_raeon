# Authority ledger for Pass 2

## Source hierarchy

1. Current explicit director decisions, including `_raeon`-only writes and no external
   `_bricked` dependency in the installed runtime.
2. Newer accepted repository design/data and versioned language source authority.
3. This Pass-2 operation/build specification, which defines implementation requirements
   but does not invent unresolved game rules.
4. Tests/fixtures: evidence only, never authority to create mechanics.

Compare incoming branch work with the source map and Pass-1 receipt. A newer timestamp
alone does not make an unaccepted change canonical. Record real conflicts; preserve
accepted upstream QMO data and do not silently downgrade a rule to make implementation easy.

## Locked facts relevant here

* Three top-level runtime objects; `sea` is lowercase, never the architectural letter C.
* Four nested singleton machine domains, State = 5D / 3+1+1. The application owns card
  state; Rainbow Road is existing transport, not a new board bus.
* Board is a stable Geometric; attachment/port relationships are not container identity.
* 60-card current format; normal FG limit two, Utility limit three, Prime identity unique.
  No extra color-uniqueness rule. Ordinary Cycle 1 = 120 FG +14 Prime +51 Utility.
* CARD instances are persistent Geometrics; canonical definitions and copy IDs differ.
* Deck/Hand/Graveyard contain cards only. Hand normal capacity seven. No discard/exile zone.
* Initial Configuration Spaces A/B/C; six additional maximum; active cap nine.
  Temporary FG capacities R3/O4/Y5/G6/B7/V8. Capacity never guarantees a field.
* Committed FGs cannot individually transfer between spaces or be freely extracted.
  Whole-space merge is later behavior; no artificial minimum of three *independent*
  post-merge spaces is authorized.
* Prime slots are fixed; ordinary Prime inactivity does not send the card to Graveyard.
* Recovery effects can return to Hand **or Deck top**, exactly as their source record says.
  Rank/color is not automatically effect count/cost. Recovery cannot reconstruct a field.
* The original imported QMO corpus and 2,094-field atlas remain unchanged.

## Policy-gated decisions, not excuses to skip the movement core

| Decision still to recover/close | Treatment in Pass 2 |
| --- | --- |
| Opening hand size/draw cadence/mulligan/first player | No automatic starting deal or turn scheduler; explicit trusted setup/action grants |
| Selected Prime placement and deck-counting/setup order | Validate roster/copy rules; isolate structural slot fixture, no invented auto-deal policy |
| Multi-card Hand overflow / short source | Primitive preflight/refusal only; do not declare full Utility outcome or spend timing |
| Utility costs, consumption and action windows | Source-linked effect primitives under trusted grants; full player play wrappers gated |
| Selection remainder order / undersized survey | Keep exact source OPEN label, no guessed chosen/random order |
| Temporary expiry/removal and merge/base accounting | Test live addition/capacity; do not add expiry or split rules |
| Destruction causal ordering | Test admitted retirement primitive; damage/support-destruction scheduling deferred |
| Initial FG pose and closure legality | Mark commitment CONFIGURING; no field/color; Pass 3 owns pose/QMO resolution |
| Refresh, attack/defense reactions, victory | Pass 4/current canon, never implied by an empty Deck or Prime state |

A test-only issuer must not become a public game command. Report which policies remain
unimplemented and which production primitives are operational. Do not inflate the pass
into complete Utilities or complete match play.

## Offline interpretation

Read-only `_bricked` access is allowed for initial development dependency recovery.
Execution uses the pinned local/bundled copy. After the declared SDK/dependency bundle
is available, build/run tests require no original checkout/network. Provenance URLs or
an internal directory named `bricked-runtime` are allowed; dereferencing GitHub or an
external checkout at startup is not.

The recovered 1,075-file dependency count and historical Windows/Python prerequisite
are source observations, not mandatory counts for a future revised bundle. Changes to
the dependency subset require hashes, reasons, notices and repeatable offline tests.
