# Acceptance and execution evidence

`acceptance/PASS_02_ACCEPTANCE.json` is the required-case inventory. Its NOT_RUN values
are specifications. The runtime audit writes a **different result artifact** tied to
actual source hashes, runtime/dependency revision, test IDs and commands. Never turn a
specification field into PASS because a named file/operation exists.

## Mandatory demonstration A — ordinary card flow

1. Boot the current Horizon and realize the empty production RAEON package; preserve
   the existing two-player topology/identities at revision zero.
2. Bind trusted player sessions. Initialize a validated 60-card inventory per player
   using current source records (the simple neutral fixture can use FG-001..FG-030,
   two copies each, if the source lookup validates those IDs).
3. Shuffle under a fixed test seed. Record owner-internal expected order privately.
   Issue admitted draw opportunities, not a fictional turn scheduler.
4. Draw seven into Hand. An eighth draw is refused with byte-identical committed
   membership/order/RNG/grants and no lost top card. Client cannot select a different top.
5. Commit one owned FG to A. Hand becomes six; A becomes CONFIGURING; no Field Topology.
   Draw once more; Hand becomes seven. Same copy identity moves across native versions.
6. An opponent's forged transfer and a committed-FG extraction attempt fail unchanged.
7. Replay the same request and a changed request-ID collision; only the valid original
   may have committed. Prove no duplicate card or second membership exists.
8. Inspect both filtered views: owner sees its Hand; opponent does not; neither can
   infer full Deck order from message IDs, catalog addresses, receipts or errors.

Counts and deterministic order expected by the test must be derived independently from
the fixture input, not by copying the resulting implementation snapshot as its oracle.

## Mandatory demonstration B — source-authorized transfers

Use a second **declared fixture setup**, not a newly invented automatic match deal, with
eligible FG/Utility/Prime records. Drive the production transfer primitive under trusted
cause/grant records. Retire eligible non-Primes, recover one eligible FG to Hand, and
recover up to three eligible non-Primes to Deck top in a chosen order. Verify the next
draw follows that order. Reject wrong-type recovery, duplicate selections, an unauthorized
Graveyard inspection and any Prime-to-Graveyard movement.

Where real Utility timing/consumption is not yet accepted, the trusted test issuer must
be visibly test-only and absent from Port exports. Test the source-linked effect primitive,
not a fake `move_list()` or a claim that the complete Utility card has shipped.

## Mandatory demonstration C — dynamic region

Start with the unchanged three initial spaces. Via verified Sandbox Activation effect
records plus trusted structural grants, admit six extra empty spaces; after each change
assert actual live counts, native State objects and independent Port projections. Test
repeated colors where copy rules allow them. At nine refuse the next request atomically.
Existing Board, region and permanent-space identities must remain unchanged, and no
configuration can auto-resolve merely because cards/spaces exist.

The production manifest must not expose a free administrative CREATE_SPACE action to
players. Utility play sequencing and temporary expiry remain explicit future work.

## Mandatory demonstration D — failure and recovery

Inject failure during a staged transfer, after source candidate update, and immediately
before root publication. In every case recover the old live State and preserve card
conservation/order. Inject delivery loss after commit, retry, and recover the recorded
outcome without advancing revision or RNG again.

Checkpoint a nonempty multi-zone board and dynamic region; restart the process with no
in-memory object registry. Restore identical card/zone/region identities, exact orders,
RNG progress, grants and semantic root, with new boundary epoch. Corrupt one checkpoint
payload and reject it without replacing live State. Replay the recorded deterministic
inputs in a fresh instance with the same declared namespace/seed and compare semantic
roots (not host timestamps or transport UUIDs).

## Mandatory demonstration E — detached distribution

Perform `05_OFFLINE_DISTRIBUTION.md` in an isolated extraction. No original checkout,
Git command, online fetch, hidden absolute dependency path or user package cache may
supply runtime components. Build/verify the shipped Genesis sources, run old and new
demos, checkpoint/restart, and compare source/bytecode/catalog hashes. Explicitly retain
Python/target-host prerequisites; this is not an iOS release claim.

## Test strategy

Use independent order/membership conservation oracles and byte decoding. Add varied
operation sequences, including random-but-seeded property tests; check after each step
that all live copy IDs are unique and conserved, capacities respected and current
membership exactly one. Exercise at least 120 cards plus all Pass-1 objects simultaneously;
one or two hard-coded test cards are not adequate scope evidence.

Check types, integer bounds, missing IDs, reusing a copy, same catalog different owner,
malformed paths, stale revisions, conflicting requests, old epochs, exhausted quotas and
unknown operations. Verify that removing a grant, closure operation or valid native route
causes the relevant end-to-end test to fail.

Use the existing runtime suite and repository validators as regressions. Source hash
guards may be amended only to the new explicitly reviewed implementation bytes; original
QMO/catalog hashes stay unchanged. Historical source guards and current runtime results
must remain distinguishable. New logic must not be implemented only in a test oracle.

## What completion means

Mandatory cases must all have evidence or remain NOT_RUN/FAIL/BLOCKED. Native-device
checks and still-OPEN gameplay decisions are not in the mandatory execution claim; the
separate policy ledger lists them. Do not silently reduce the denominator or replace an
unrun runtime case with a documentation review. Report exact counts for tests versus
requirements; one parametrized test can exercise multiple requirements only when each
assertion/evidence mapping is explicit.

A final statement may say "Pass 2 software operations complete under declared trusted
admission and reference-host scope" only when demonstrated. It may not say the entire
match, all Utilities, native platform, or offline release installer is complete.
