# Pass 2 build order

## 1. Scope and exit product

The deliverable is the next executable version of the **same** production RAEON Genesis
application. Pass 1 remains reproducible: one empty Match, two Players/Boards, existing
attachments, empty containers, three Prime positions and A/B/C spaces per player.
Pass 2 adds card instances and movement **after** that empty realization, not by silently
changing the default boot into a fully dealt match.

A headless operator can initialize a legal card inventory, shuffle it, draw under an
admitted action, commit an FG, retire/recover an eligible card under a trusted effect,
and observe the result. The actual card membership and order live in authoritative
State, not in a renderer, test dictionary or Hypervisor cache.

No implementation of pose-to-manifold matching, Fusion, Emergence, damage, healing,
Prime charges, turn refresh, victory or animations is requested here. Future passes use
the identities, movement primitives and dynamic collections established now.

## 2. Where to put the work

Reuse the current module map. Suggested homes are binding targets, not instructions to
duplicate existing files:

| Work | Existing home / placement rule |
| --- | --- |
| RAEON manifest and entry programs | `game/core/raeon/application/` |
| Reusable card definitions/identity handlers | Existing `game/cards/` modules linked by the application |
| Ordered deck/hand/graveyard operations | Existing `game/deck/`, `game/board/` or application modules; one owner per concern |
| Generic Genesis host adapters | `game/core/genesis_horizon/bindings/python/src/raeon_genesis_horizon/` |
| Wire/schema compatibility only | `platform/shared/python_hypervisor/` |
| New executable integration tests | Existing `tests/integration/genesis_horizon/` or registered RAEON integration submodule |
| Canonical input data | Existing `data/cycles/`, `data/board/`, `data/topology/`, `data/qmo/` read-only catalogs |
| Derived runtime catalog and contracts | Deliberate `data/` home with source hashes; never overwrite imported originals |
| Build/test/distribution | Existing `tools/genesis_runtime.py` family and ignored `build/genesis_runtime/` |
| Maintained handoff/receipt | `development/modules/core-game/` following Pass 1 |

Source can be organized in several `.gen` modules. A loader must link/resolve them with
the supported toolchain and package all their hashes. Do not concatenate incompatible
grammars, duplicate the compiler, or introduce empty per-card program files.

## 3. Ordered implementation units

### P2-W00 — Recover and reproduce Pass 1

Establish actual remote/local refs and untouched-main state. Run dependency verification,
the conformance demo, empty `raeon` demo and current tests. Distinguish an existing failure
from a new regression. Preserve useful changes and upstream byte locks. Initialize a
single execution record and read source boundaries before coding.

### P2-W01 — Bind catalogs and classify policy

Build a read-only runtime view of authoritative card records. Required catalog identities
are FG=120, ordinary Prime=14, ordinary Utility=51 when supported by the current accepted
source. Preserve Black/special records and historical sources without folding them into
the ordinary 185 or inventing Black FGs.

For missing final printed IDs use a documented internal handle derived from a pinned
source record/path plus stable key; retain its OPEN/PROVISIONAL label and original source
address. Do not generate new card designs or pretend a working rank is a finalized cost.
Resolve every runtime alias back to its record; ambiguous/missing input must fail with
source evidence, not receive a guessed definition. Verify unused records remain intact.

Determine whether current sources fix the initial placement/counting of selected Primes.
If not, keep that separate from inventory initialization. The neutral initialization
fixture can use a valid 60-card FG/Utility roster, leaving Prime setup explicitly gated.
This proves deck/card infrastructure without choosing an opening-match rule.

### P2-W02 — Implement generic application values and input binding

Pass-1 native bindings were finite fixtures, not a parameterized card runtime. Add typed,
effect-bounded arguments, application-owned dynamic instance registration, and persistent
ordered membership using supported Genesis data/control/callable primitives. Read
`03_GENESIS_INTEGRATION.md` before extending the binding.

Resolve IDs to live objects under trusted owner/application context. Reject unknown fields,
invalid types, stale revisions and unauthorized references before publishing anything.
Pass zero-argument OBSERVE through unchanged. Keep old package conformance compatible.

### P2-W03 — Instantiate card copies and initialize inventories

Validate each proposed 60-card roster: canonical/working source authority, per-identity
limits FG<=2 / Utility<=3 / Prime<=1, legal profile, ownership and absence of duplicate
runtime IDs. Treat these as current format constraints, not constants embedded in Board.
Realize actual card Geometrics through Genesis. Mint separate identities for distinct
copies, bind catalog/QMO provenance, create current container membership and ordering,
and atomically publish the initialized inventory.

Initialization is a trusted setup operation, unavailable as a normal gameplay spawn.
Repeating the same request must not duplicate inventory. Replacing a live inventory or
resetting a player's deck requires separately declared authority; do not implement a free
mid-game reset. Stage both-player setup under one transaction when supported, or prove
per-player atomicity and record that setup is not yet a turn scheduler.

### P2-W04 — Ordered containers, shuffle and draw

Choose and document one logical order convention: index zero is next/top. Stored identity
must not depend on list position. Shuffle preserves the multiset; draw moves the next
card into the owner's Hand only after capacity/admission succeeds. The Hand has capacity
seven, not an automatic initial deal of seven. Empty Deck is an operation refusal or
no-available-card result, not a victory/defeat rule.

Use a fixed versioned deterministic shuffle algorithm and persist its state/counter.
Random seed authority belongs to trusted setup, not a player-forged seed. Do not leak
seed, future deck order or catalog-bearing copy IDs. Use a predeclared admitted draw
opportunity in tests; no once-per-turn rule is assumed.

### P2-W05 — Deployment and authorized retirement/recovery

Commit FG copies from Hand to an owned Configuration Space. Preserve catalog and copy
identity/history; expose the deployed representation; set a previously EMPTY space to
CONFIGURING. Do not produce a field/color from count, do not test pose legality yet, and
do not give committed FGs an individual extraction/space-transfer operation.

Implement structural Prime-slot binding under trusted setup authority, with slot and card
identities distinct and occupied-slot rejection. Prime health/charge/activation remains
Pass 4. A Prime is never sent to Graveyard by a generic retirement request.

Implement batched retirement of eligible non-Primes and recovery transfers with a trusted
cause/effect, preserving order and selected identities. Recovery selection must be
allowed by the actual Utility effect's type/count/destination. Implement the unambiguous
movement core; complete Utility play/consumption/timing policy remains gated when OPEN.
No default discard pile, exile zone or freely callable restore-from-Graveyard operation.

### P2-W06 — Dynamic Configuration Region carry-forward

Prove this correction now so it does not become a later Board rewrite. Initial membership
is A/B/C and zero extras. There is one persistent Configuration Region per Board whose
membership changes; it is not three fixed fields or nine pre-created space instances.
Create six additional spaces through the shared, admitted creation/membership path,
using existing Sandbox Activation capacity definitions; reject a tenth active space.
Do not impose color uniqueness: duplicate Utility identities/copies follow card limits,
not a one-per-color house rule. Preserve Board/region/permanent identities throughout.

This pass implements the structural effect primitive with a trusted conformance grant,
not a new freely available player action or unresolved Utility cost/window. Temporary
space removal/expiry, merge accounting and split remain later policies. Never generalize
"three initially permanent" into an invariant that at least three independent spaces
must always remain after a future legal merge.

### P2-W07 — Privacy, recovery and adversarial integration

Exercise every command through the real byte Port/Hypervisor/Horizon. Query projections
from committed State; do not return pass1's frozen `contents: []`/static view lists when
live cards now exist. An owner sees its Hand, not unrestricted future Deck order.
Graveyard inspection is effect-authorized as current canon prescribes. Only already
public/deployed cards expose their permitted visible attributes.

On failed admission retain source membership, order, counters, grants, region membership,
State root and revision. On a committed result followed by lost delivery, retry returns
the original outcome. Duplicate IDs with changed arguments conflict. Checkpoint/restart
and replay retain card/zone identities, deck order, RNG progress, effect-grant state and
dynamic memberships.

### P2-W08 — Distribution, evidence and remote checkpoint

Update package inventories and source guards for the new legitimate code without
weakening the original-data guards. Build matching distributions, include the runtime
catalog inputs and exact dependency subset, and run the isolation tests in
`05_OFFLINE_DISTRIBUTION.md`. Preserve the old empty-state/conformance scenarios and add
a card-operation scenario; Pass 2 must not be merely a passing Python model.

Commit and push the authorized task branch. Produce one Pass-2 receipt, a current
machine-readable result and the exact Pass-3 entry condition. Do not conflate software
pass completion with module GOLD or whole-game release acceptance.

## 4. Source ownership versus data ownership

The card corpus supplies identities and definitions. The Genesis program supplies card
movement/admission/collection semantics. The generic reference binding implements the
language's execution services and host persistence. The Hypervisor transports results.
Each rule must have one owning source and an executable test; duplication across these
layers is not a shortcut to completion.
