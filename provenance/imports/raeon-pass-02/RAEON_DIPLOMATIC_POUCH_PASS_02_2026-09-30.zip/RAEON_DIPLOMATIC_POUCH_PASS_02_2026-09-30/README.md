# RAEON · Diplomatic Pouch 02
## Cards, containers, and identity-preserving movement

**Open first:** `00_EXECUTE_THIS_FIRST.md`  
**Writable repository:** `xApologies/_raeon` only  
**Upstream:** `_bricked`, read-only source provenance and pinned development dependency  
**Entry milestone:** Pass 1 on `codex/raeon-pass-01`, observed at
`23ebfc3be3a4e6ae4883793bfc99b1dbfae67bf8` on September 30, 2026.

Give this archive to the existing Codex workspace and say:

> Execute according to `00_EXECUTE_THIS_FIRST.md` inside this Diplomatic Pouch.

This is an executable-work assignment, **not the implemented game**. It specifies the
source, interfaces, negative cases, integration scenarios, packaging, and Git evidence
Codex must produce. Acceptance cases start `NOT_RUN`; they are not passing test results.

### Outcome

Keep the real empty RAEON match from Pass 1. Add a content-backed card-copy layer,
ordered containers, deterministic shuffle, admitted draw/deployment/recovery operations,
and atomic membership changes. Prove those operations through compiled Genesis, the
existing Horizon, the Hypervisor and an independent byte-facing test Port.

Two explicit carry-forwards are included:

* The Configuration Region is dynamic: three permanent initial spaces, up to six
  additional admitted spaces, nine active maximum before any later merge accounting.
  Prove live membership changes without rebuilding the Board.
* A packaged development build and runtime must work with the original `_bricked`
  checkout absent and with no GitHub/network access. Historical source references are
  provenance, not live runtime lookups.

Full field resolution, pose legality, emergence, Prime H/C arithmetic, turns, combat,
and native graphics remain later-pass work. No new game rules are authorized by this pouch.

### Reading order

1. `00_EXECUTE_THIS_FIRST.md` — the complete starting prompt.
2. `01_PASS_02_BUILD_ORDER.md` — deliverables and implementation sequence.
3. `02_STATE_AND_OPERATIONS.md` — data ownership and operation contracts.
4. `03_GENESIS_INTEGRATION.md` — exact current limitations and required integration work.
5. `04_ACCEPTANCE_AND_SCENARIOS.md` plus `acceptance/` and `fixtures/`.
6. `05_OFFLINE_DISTRIBUTION.md` and `06_GIT_AND_RECOVERY.md`.
7. `authority/` and `continuity/` — source navigation, decision boundaries, next-thread recovery.

Integrate into the existing repository homes. Do not extract this instruction tree into
canonical source, copy in obsolete chat ZIP implementations, or create another project.
