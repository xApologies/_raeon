# State and operation contracts

The record/operation names below are **implementation-contract vocabulary**, not claimed
Genesis syntax or new architectural domains. Express them using the supported Genesis
language; use versioned internal names only where current code lacks equivalent contracts.

## 1. Authoritative records

### CatalogRef

A canonical card identity resolves to one immutable record: source file/key or QMO address,
source revision/hash, card family/profile, accepted data and any PROVISIONAL/OPEN fields.
Catalog identity is not copy identity. The runtime must not edit this record to move a card,
mark it used, change a player's inventory, or build a topology.

### Card instance

Required semantic fields: instance identity; catalog reference/hash; immutable owner for
this pass; current containing identity; representation status (container CARD or deployed
FG/slot Prime as applicable); persistent history/ancestry. Distinct copies of one card
share the catalog reference but not the copy identity. Native immutable successor IDs
may change while the logical instance ID remains stable.

Do not encode card name, family, rank or deck position into a public opaque hidden-card
identifier. Opponent snapshots, event payloads and errors must not disclose private
catalog references or correlate an unknown future draw to a known initial roster.

### Ordered card container

A stable container ID has a profile (DECK/HAND/GRAVEYARD), owner, cardinality policy,
ordered live membership and access policy. The logical order is explicitly defined and
serialized; it is not derived from hash-map traversal, current filesystem order or a
renderer. Any materialized index is reconstructible from authoritative State.

For this pass, each realized card has exactly one current containing zone/slot/space.
Historical containment edges remain History, not simultaneously active membership.
Moving a card retires the prior *active* membership and creates its successor; it does
not erase history or leave the card live in both zones.

The Board container capacity is data-driven. The current constructed deck validation
requires 60 cards; do not hard-code 60 as the maximum cards the Board can ever reference.
Hand's normal admission cap is seven. Additional deck-size formats remain unauthorized
until accepted, even though the data structure does not require a Board rewrite.

### Configuration Region and spaces

Region identity is persistent. Its current membership is a live relationship collection.
A/B/C are permanent initial objects. Additional objects are created when an admitted effect
requires them. Capacity contracts are distinct:

* Board/region active space cap: nine; at initialization three permanent plus zero extras.
* Maximum additional active spaces before merge accounting: six.
* Temporary space FG capacities: Red 3, Orange 4, Yellow 5, Green 6, Blue 7, Violet 8,
  verified from current sandbox authority before coding.

Color capacity is not proof of a field or its color. Permanent universal capacity and any
merged ceiling follow source authority; do not turn an unknown into an arbitrary cap.
No individual extraction of committed FGs, no field production, and no temporary expiry
are introduced here.

### Trusted action/effect grant

The later scheduler decides when an action is playable. Pass 2 requires an explicit,
bounded grant whose issuer is trusted Horizon/application setup, not untrusted Port JSON.
Its record binds application/match, actor/owner, allowed operation, relevant card/space,
source effect record, allowed count/type/destination, expected State and replay identity.

A player can request an action; it cannot supply `admitted=true`, a new owner, a new
catalog definition, or a free-form effect/authority dictionary that grants permission.
Conformance-only grant issuance is excluded from player exports and normal startup.
Durable grant consumption and operation outcome are committed with the mutation. A retry
of the same committed request returns that outcome rather than consuming a second grant.

This is an engineering admission boundary for deferred timing, not a replacement game
rule or a second transport/security engine.

## 2. Operation specification

### CATALOG_LOOKUP / VALIDATE_ROSTER

Read canonical sources from packaged/local data. Accept a format ID plus catalog IDs and
multiplicities, not caller-supplied effect definitions. Enforce known records, positive
integer quantities (booleans are not integers), total 60, FG<=2, Utility<=3, unique Prime
identity, and applicable accepted inclusion rules. Unknown/ambiguous records fail closed.
Do not impose six-color uniqueness or turn a provisional rank into a cost. Validation
alone creates no card and leaves State/RNG/semantic revision unchanged.

### INITIALIZE_INVENTORY — trusted setup

Preconditions: Pass-1 RAEON realized, valid owner/roster, correct version/expected revision,
unused setup grant, no conflicting initialized inventory. Admit all proposed definitions,
source bindings and copy IDs before publication. Instantiate copies through Genesis and
attach them to that owner's Deck with an explicit initial order; one atomic successor
per declared batch. Hand and Graveyard remain empty.

Success: 60 new card-copy identities for that roster, exact validated multiplicities,
no changed existing Board/region identity, a scoped receipt and private source provenance.
Same request and inputs are idempotent; conflicting reinitialization is rejected.

This neutral inventory load is not the final start-match procedure. In particular it does
not settle opening hand size, auto-slot Primes, decide whether selected Primes count
inside/outside a shuffled pile, or choose the first player. If those remain undefined,
use an all-FG/Utility legal test roster and isolate Prime slot tests under setup authority.

### SHUFFLE_DECK — setup/effect authority

Reorder only the owner's admitted Deck membership. Preserve every copy, all immutable
catalog references, and the card multiset. Use versioned deterministic RNG and exact
algorithm vectors; use unbiased index selection for a Fisher–Yates implementation or
an existing approved equivalent. Do not depend on Python's global random state or host
clock. Stage RNG counter and order together; failure/retry cannot burn extra random steps.

Golden tests use a declared fixture seed/namespace and assert the entire order. Production
seed input comes from trusted setup, remains private, and is never chosen via a free
player command. Deterministic replay is not a promise of cryptographic security.

### DRAW_ONE — admitted draw opportunity

Resolve actor to its Deck and Hand. Resolve the top card internally; client cannot select
a hidden card by claiming it is top. Validate Deck nonempty, Hand has room, exact current
membership, card profile and grant. Transfer one copy; update both orders atomically.

A full Hand leaves Deck/Hand, source top, RNG, grant, revision and root unchanged. An
empty Deck produces a defined no-card/refusal result, not automatic loss/end turn. Seven
is the capacity; no seven-card opening deal or draw-per-turn cadence is invented.

### COMMIT_FIELD_GENERATOR

Accept existing owned Hand copy and owned Configuration Space reference plus expected
revision/grant. Verify card is FG, destination is live/admitted and has capacity, source
still contains that copy, and no committed-extraction rule is bypassed. Traverse the
existing local Rainbow Road/Portal machinery under the application State domain.

Publish Hand removal and space membership plus deployed FG representation atomically.
Preserve identity/QMO reference/History. EMPTY -> CONFIGURING; no active topology or color.
Any retained pose data must be explicitly unvalidated; XY/3D manipulation belongs to
Pass 3. Do not assign a made-up valid orientation. Attempts to directly transfer a
committed FG to another space/Hand fail under current rules.

### BIND_PRIME_POSITION — structural setup contract

Resolve an existing Prime copy and an owned unoccupied fixed position under trusted
setup authority. Bind without replacing position identity or cloning the card. Source
movement, if part of the supplied setup scenario, is explicit and atomic. Reject wrong
profile, wrong owner, occupied position, a fourth position, and reuse of a bound copy.
No outgoing color, H/C changes, activation or combat here. No invented production
Hand-to-Prime timing; the structural fixture demonstrates the binding capability only.

### RETIRE_CARDS — trusted resolved-cause contract

Accept a finite set of eligible card references with a validated effect/destruction cause.
Do not expose arbitrary card movement as a player administrative power. A trusted
fixture may supply a resolved cause to test the primitive, without implementing field
damage/expiry ahead of Pass 4.

Validate the whole set and its order before changes; append to ordered Graveyard,
preserving copy history. Single-card insertion places it at the logical newest/top end;
untouched cards keep relative order. A supplied explicit batch order is honored. Where
actual simultaneous-destruction order remains OPEN, the public wrapper stays gated.
Primes never retire to Graveyard. A committed-FG retirement requires an admitted whole
support/destruction cause, not the prohibited independent extraction action. There is
no additional discard/exile container.

### RECOVER_CARDS — authorized Utility effect primitive

Read the effect from `data/cycles/cycle_01/utilities/recovery.json` or its accepted successor.
Verify the acting Utility/effect grant and eligibility of every selected existing card.
Respect actual source entries: FG-only recovery, Utility-only recovery, non-Prime
recovery, and up-to-three non-Primes to Deck top in player-chosen order. Do not collapse
every recovery into Graveyard -> Hand. The top-deck order uses first-selected = next draw,
with the convention recorded. Source Graveyard survivors retain relative order.

Validate destination capacity for the whole requested batch before commit. A primitive
unable to fulfill the requested batch returns a policy/capacity refusal with no mutation;
it does **not** invent how a full game resolves multi-card overflow or consumes a played
Utility in that case. Preserve PROVISIONAL rank metadata as such. A recovery does not
reconstruct the destroyed manifold or reactivate a Prime.

### EFFECT_TRANSFER_BATCH / INSPECT_ORDERED_RANGE — shared internal primitives

Provide bounded, source-linked inspection/transfer helpers for the existing draw/deck
Utilities. Source-defined Draw 1/2/3, Survey/Exchange and recovery effects can reuse them
when all necessary parameters are already authorized. Selection's unresolved remainder
order, short-deck handling, overflow and play timing stay in the policy ledger. No
unrestricted tutor, free discard/draw cycle, or broad Graveyard read export is added.

Do not claim every Utility is fully implemented because its lower-level helper exists.
In this pass it is sufficient to exercise the relevant helpers and recoveries under
trusted grants; remaining Utility rule execution stays visibly deferred.

### ADMIT_ADDITIONAL_CONFIGURATION_SPACE — structural effect primitive

Input is a verified Sandbox Activation source record and bounded authority; client cannot
invent rank/capacity. Obtain FG capacity from canonical R/O/Y/G/B/V definitions. Resolve
the existing owner's region, verify extras <6 and active spaces <9, mint one new semantic
identity without embedding display position, instantiate the actual empty Geometric and
add current ownership/containment/visibility relationships atomically.

No dormant S1–S6 objects are prepopulated. In a fresh region run the primitive six times
and observe memberships 3,4,...,9. The next attempt fails without losing a card/grant or
changing any prior membership. Region, Board and A/B/C retain identity. Test repeated
colors with distinct legal source copies; no additional color-uniqueness law.

This is not implementation of temporary expiry, merge bookkeeping, full Utility play
cost/consumption or the entire topology engine. In fixtures the issuer supplies an
admitted effect, with the production free-spawn route absent.

### OBSERVE

Build authorized views from committed **live** membership and order. Do not return stale
manifest lists that omit new cards/spaces or static pass1 `contents: []`. Owner Hand view
may show held cards; default Deck view must not reveal full order even to its owner.
Survey/recovery permissions authorize bounded additional views, not permanent access.
Graveyard visibility follows source rules, not the assumption that every owner may browse.
All result/error/event/delta paths apply the same filtering. A copied mutable projection
cannot change State. Observation does not advance the gameplay revision.

## 3. Common mutation algorithm — pseudocode, not Genesis source

1. Validate wire shape, then bind trusted session and expected State version.
2. Look up scoped request outcome; identical committed retry returns it, altered retry fails.
3. Resolve operation and references in the admitted application, never raw paths/pointers.
4. Validate the action/effect grant and source rule, owner, profile, capacities and membership.
5. Build a candidate transaction with resolved source/destination/order and bounded resources.
6. Compile/verify or use verified cached Genesis handler for that operation.
7. Route inward through sea/Shell/Nexus; execute State-local admitted logic and native
   movement/relationship transforms through existing Road services.
8. Verify candidate card conservation, unique live containment, scope and closure.
9. Stage every changed index/root, RNG progress, grant consumption and receipt together.
10. Atomically publish one successor; rejected candidates cannot change live references.
11. Produce filtered observations/receipts and route outward. A delivery failure after
    commit is COMMITTED/RECOVERABLE, never retrospectively REJECTED.
12. Checkpoint/replay serializes the same authority-bearing state, not only visible cards.

## 4. Semantic invariants and failure checks

For each initialized owner, the union of all live container/slot/space card memberships
has the same copy-ID multiset as its validated inventory unless an explicitly accepted
future creation/destruction rule changes it. Retiring to Graveyard is a movement, not
card deletion. Card family is a catalog property, not inferred from location.

The semantic root must commit to live membership, logical order, copies/catalog binding,
ownership, RNG progress and dynamic regions as appropriate. A shuffle that only edits
an uncommitted Python list is not an authoritative state change. Index rebuild must
reproduce State exactly; native successor version IDs do not replace stable card IDs.

Test every negative operation after serializing the pre-state: equal semantic root,
revision, orders, memberships, grants and RNG after rejection. Private transport receipts
may grow only as explicitly documented non-game audit data; they are not hidden successful
mutations. Failed candidate resources must be reclaimed or safely bounded and accounted.
