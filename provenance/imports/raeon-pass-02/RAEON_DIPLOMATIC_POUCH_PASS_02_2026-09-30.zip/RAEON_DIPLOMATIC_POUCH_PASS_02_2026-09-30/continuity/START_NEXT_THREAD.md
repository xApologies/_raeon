# Resume without reconstructing RAEON

Give a new chat this pouch and the latest Codex Pass-2 receipt, then say:

> Continue RAEON from the current Pass-2 receipt. `_raeon` is the sole write destination
> and the development landscape. `_bricked` is read-only source provenance. Recover the
> current branch/SHA and execution record before preparing the next Diplomatic Pouch.

Four-pass roadmap:

1. Empty application/match realization — prior source and receipt are in Git.
2. Cards, ordered containers and admitted transfers — **this pouch**, plus the explicit
   dynamic-region/no-external-runtime-dependency carry-forwards.
3. XY placement, 3D orientation, corpus-driven fields, whole-space merge and emergence.
4. Prime H/C, color production/transduction, READY/USED and accepted turn authority.

The complete machine remains Genesis Horizon <-> Python Hypervisor <-> Platform Port,
with one sea containing Shell containing Nexus containing State. Do not redesign it or
confuse Python reference bindings with a Python-only game. The application ID stays raeon.

At entry the observed Pass-1 branch was `codex/raeon-pass-01` at
`23ebfc3be3a4e6ae4883793bfc99b1dbfae67bf8`. It reported an empty board at revision zero,
37 application Geometrics and 163 relations, OBSERVE only. Those counts describe initial
state; they are not limits on future objects.

No Pass-2 code was executed or pushed when this pouch was authored. Recover actual
results from Git/Codex, not this document's existence or the original chat's completion
language. The original framework test results were recorded by Codex; this pouch's
validation concerns the instruction artifact only.

A successful Pass-2 receipt hands Pass 3 actual deployed FG copies, preserved catalog
references, ordered containers, dynamic regions, replay/checkpoint data and permissioned
projections. It does not claim any field closure, full-match play or native rendering.
