# CODEX EXECUTION ORDER — DIPLOMATIC POUCH 02

Implement **RAEON Pass 2: card identities, containers and admitted movement** directly in
`xApologies/_raeon`. Continue the existing project; do not summarize this document and
stop, generate another plan in place of code, or reimplement the machine from scratch.

## 1. Recover and establish the baseline

Read this entire pouch, applicable `_raeon/AGENTS.md`, the repository constitutions,
`development/PIPELINE.md`, the current runtime execution record and Pass-1 receipt.
Inspect the actual working tree before any checkout. Preserve unrelated/uncommitted work.

The observed Pass-1 remote is `codex/raeon-pass-01` at
`23ebfc3be3a4e6ae4883793bfc99b1dbfae67bf8`. The runtime foundation is ancestor
`71b3a3fbdbce7eece25076a0fd303887cc70d4f1`. Do not start from an older `main`
that lacks this work. Fetch and identify newer accepted successors; never reset to the
snapshot just to satisfy this document. Continue/create `codex/raeon-pass-02` or the
existing equivalent branch from the recovered Pass-1 lineage. No main merge/force-push.

Write only to `_raeon`. Read `_bricked` only for authorized Genesis/Fabric/Road sources.
Use pinned isolated dependency copies; do not edit, commit, branch or push in `_bricked`.

## 2. Preserve the machine and extend the application contract

There are exactly three architectural objects:
`Genesis Horizon <-> Python Hypervisor <-> Platform Port`.
The Horizon contains one `sea`, one Shell, one Nexus and one State, nested in that order.
Chirality Fabric is foundational; Rainbow Road is the existing internal transport.

RAEON is implemented in actual Genesis source inside State. Python is allowed for the
existing compiler/reference runtime, generic binding, boundary translation, tests and
build tooling. Do not move draw, copy limits, recovery rules or board policy into the
Hypervisor, and do not replace Genesis handlers with a Python game engine.

The current adapter is deliberately Pass-1-sized: nonempty intent arguments are rejected,
application definitions are static, native transforms are narrowly allowed, and only
machine-adjacent request traffic is routed. Implement the **compatible, tested binding
work described in `03_GENESIS_INTEGRATION.md`**. Preserve the four-domain architecture;
this authorization is not a request to freeze those fixture restrictions forever.

## 3. Implement the pass

Evolve `game/core/raeon/application/` rather than create another application. Implement:

* source-backed catalog access, stable per-copy Geometric identity and provenance;
* a validated, owner-bound 60-card inventory/deck initialization operation;
* deterministic seeded shuffle and safe ordered Deck/Hand/Graveyard access;
* one-card draw with Hand capacity seven and no source loss on refusal;
* admitted FG commitment into Configuration Space, keeping the same card identity;
* structural Prime slot admission under explicit setup/test authority, without combat;
* cause-authorized retirement/recovery transfers and ordered batch primitives;
* dynamic Configuration Region membership, preserving initial A/B/C and supporting
  six additional admitted spaces up to nine; no hard-coded three-space architecture;
* owner-scoped projections, transaction receipts, replay and checkpoint/restart.

Implement the operation bodies and invariants specified in this pouch, not just manifest
entries bearing their names. Reuse source catalog definitions; do not regenerate QMO data.

## 4. Respect missing gameplay policy without abandoning executable work

Draw cadence, opening hand, Prime setup sequencing, costs/windows, overflow, temporary
space expiry and victory are not to be invented. Build and test the underlying operations
under **explicit trusted action/effect grants**, with the grant issuer confined to the
conformance harness until the relevant game scheduler exists. Client JSON cannot grant
itself authority. Do not add free-draw, free-recovery or free-space-creation gameplay.

All mandatory core cases still require real execution. A policy gate is not a passing
implementation of the gated feature. Put unresolved end-user sequencing in the separate
policy-gated ledger. Continue all independent work rather than repeatedly asking for approval.

## 5. Test, package and persist

Use `execution/WORK_QUEUE.json` and `acceptance/PASS_02_ACCEPTANCE.json` as independent
requirements. Implement the tests before treating their cases as satisfied. Run the
actual Genesis compiler/linker/verifier/runtime, negative tests, the old conformance
and empty-board demos, and new two-player card-operation scenarios through the real
Hypervisor. Preserve all prior behavioral invariants and QMO source protections.

Extend the existing `tools/genesis_runtime.py` task family. Provide real commands for
Pass-2 build/demo/tests/audit. Packaging must include the application catalog inputs and
required runtime subset. Test a fresh offline extraction with no original `_bricked`
checkout, no dependency-path override and no Git executable used by build/run. Python
and target-native SDK requirements must be stated honestly, not declared bundled by name.

Save source continuously; make coherent commits and push the authorized `_raeon` task
branch. Maintain one current execution record and a Pass-2 receipt, not a second project
of status documents. New thread recovery must name exact local/remote commits, tests and
next action. Do not rewrite historical acceptance results to make new results appear green.

Finish with implemented paths, source/compiler revisions, Genesis handlers and generic
binding changes, actual tests/case coverage, offline proof, archive paths/hashes, local
and remote SHA, and the precise Pass-3 entry state. If blocked, retain all valid work and
report the exact missing operation/source/failed command; never call the task complete
because its documents or string-search tests passed.
