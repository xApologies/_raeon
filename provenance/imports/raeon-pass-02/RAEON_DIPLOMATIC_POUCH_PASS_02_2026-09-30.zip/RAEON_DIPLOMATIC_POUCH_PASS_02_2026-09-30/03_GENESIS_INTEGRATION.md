# Genesis implementation map and current compatibility work

## 1. What was actually inspected

This pouch was prepared after reading the remote Pass-1 branch at
`23ebfc3be3a4e6ae4883793bfc99b1dbfae67bf8`. See `authority/SOURCE_MAP.json`.
These are source observations, **not new execution results**:

* `adapter.py::execute` rejects `intent['arguments'] != {}`. RAEON currently exports
  OBSERVE only. Card identifiers/destinations/batches therefore need typed argument support.
* `native.py::instantiate` allows application definitions during realization only, rejects
  unknown handles and duplicate bindings, and distinguishes `bound_` resource lookup.
* `native.py::transform` supports MIRROR_CHIRALITY and INHERIT_STATE only; `fork` and raw
  overlay writes are rejected. A named new card operation is not already implemented.
* `native.py::portal_open` currently permits request traffic on machine-adjacent corridors.
  Transport of cards between State-local containers requires an actual admitted local
  endpoint/profile path, not just a decorative Road receipt for an unrelated request.
* Application package schema/verification is geared to a declared finite realization graph;
  the current projection uses declared lists/fields. Dynamic cards/order/spaces require
  a versioned live-state contract while preserving that initial graph proof.
* The source distribution currently includes runtime sources and Windows-specific wheels;
  build/run independence must also include the newly required game catalogs and bindings.

Do not treat these as reasons to abandon Pass 2 or silently put the game in Python.
They are the explicit application-integration work of this pass.

## 2. Allowed changes

Keep machine cardinality, containment, domain roles, read/write mediation and external
fence architecture unchanged. Compatible additions to generic Horizon application
bindings in `_raeon` are authorized where required for typed arguments, dynamic State
collections/instantiation, native card transport and persistence. Each change must name
its previous restriction, new contract, `.gen` caller and independent negative test.
No write to `_bricked`; any dependency compatibility patch is an identified local patch
with pinned original hashes and a documented source/ABI decision.

The 37 application Geometrics at empty boot are a baseline, **not the allowed total for
all future operations**. Likewise the Pass-1 163 relationships are an initial topology
assertion, not a live-graph size constant. Keep that baseline test and add tests showing
legal growth. Do not pass dynamic tests by deleting the old baseline test.

## 3. Required language investigation and use

Use the current upstream entry points and reference tests from Sections 2/3/4/5 for
instances/transforms/Portals/Road; Sections 8/9/10 for actual compilation/linking/execution;
Sections 12/13 for package/callable composition; Sections 14–17 where data, control,
recursion or capability services are genuinely needed. Section 20 pins the release.
Do not rerun a multi-gigabyte archive crawl instead of following current registries.

Graph `genesis 0.1.0` is one supported source profile in the frozen release, not the whole
language. A `0.6.0` header is not a license to concatenate graph and system-I/O syntax.
Run baseline examples and confirm the chosen composition path, then compile each new
handler and preserve GIR/bytecode/verification evidence. Preserve verifier-before-run.

The current GVM has bounded per-program resources. Read its exact limits. If a monolithic
roster realization exceeds them, compose bounded verified units with an atomic candidate
publication protocol, or use supported callable/control machinery. Do not remove verifier
checks, raise limits without a versioned tested contract, or use `eval`/`exec`/untrusted
source interpolation as a substitute for argument binding.

## 4. Required code responsibilities

The source names below are proposed `.gen` implementation units, not claims these files
already exist. Consolidate/reuse equivalents to keep the tree clean:

| Unit | Must do in supported Genesis/application semantics |
| --- | --- |
| inventory realization | Bind admitted catalog records to distinct copy instances and initial container membership |
| ordered membership | Query/update authoritative current ordering and live relationships |
| shuffle | Invoke the approved deterministic order transformation with retained RNG state |
| draw | Validate admitted source/destination and move one existing copy |
| FG commitment | Move Hand membership to an owned space without QMO closure |
| Prime binding | Admit a structural slot attachment without H/C/combat |
| retirement/recovery | Apply source-linked bounded batch transfers, no arbitrary resurrection |
| region membership | Admit additional space instances and preserve the 3+6/9 capacity contract |
| observation | Produce permitted live views rather than fabricated static fields |

Python may implement the supplied compiler/reference backend and narrowly typed generic
services. It may parse/verify immutable data, serialize, persist and enforce generic
ownership/resource contracts. It must not special-case `if operation == DRAW` or embed
a 185-card decision engine in the Hypervisor. Policy such as Hand<=7, copy limits,
FG-only destination and recovery target restrictions must be declared/executed by the
Genesis application/accepted data path, with binding code limited to generic execution.
If a generic host service performs an operation, explain its language-level caller,
arguments/effects, authority and outcome; tests must prove bypassing that caller cannot
publish gameplay state.

## 5. Data and arithmetic binding

Version and validate argument schemas. Bind card ID, container ID, selected-copy list,
order, grant handle and expected revision as typed application values, not as source
text pasted into code. IDs cannot resolve outside the owner/match unless canon permits.
Booleans cannot satisfy integer counts; duplicate selections and stale membership fail.
Profile parameters and catalog data remain immutable and hash-bound.

Use the existing interpreter services for integer/data operations; a new source keyword
is not required merely because a record is called Card or Deck. A truly absent primitive
requires an explicitly labelled `PROPOSED_EXTENSION` with parser/checker/lowering/backend
and tests before any claim of support. The pouch itself introduces no new Genesis syntax.

## 6. Native identity and mutable relationships

Distinguish immutable catalog definition, persistent logical copy, native immutable
version, live containing relationship and history. Use the actual local transport engine
for card information as well as the existing machine-adjacent Road for external traffic.
Preserve the same copy identity, native ownership and ancestry on a transfer. Reconcile
old active membership through native supported successor semantics; do not append a
second live edge and rely on UI code to hide the original.

Any new State-local endpoints are instances within the application, not additional
machine domains or a second Rainbow Road implementation. An invalid cross-owner route
must fail before commit; a malformed Road or unclosed Portal cannot authorize transfer.

## 7. Package/capability migration

Keep `raeon` as the application ID and version its evolved package. Preserve old manifest
hashes as history. Define compatibility of old zero-argument test packages and Pass-1
checkpoint data explicitly. New checkpoints must reconstruct dynamic definitions,
catalog references, active memberships/order, grants and RNG from their committed data.
Never remint card IDs on restore. An incompatible old checkpoint must be rejected with
a version/migration explanation, not silently initialized into a new empty match.

Do not permit a manifest to grant arbitrary host filesystem/network or system-domain
mutation. Keep native diagnostics in trusted evidence. Preserve all four domain IDs
through card operations and proof of original machine-profile integrity.
