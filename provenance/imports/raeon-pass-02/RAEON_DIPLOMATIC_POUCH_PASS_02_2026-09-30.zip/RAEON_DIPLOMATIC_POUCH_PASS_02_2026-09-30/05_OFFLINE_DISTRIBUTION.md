# No external `_bricked` runtime dependency

## 1. Director's requirement

`_bricked` currently houses the Genesis language and is the source authority for the
pinned development dependency. It must **not** be an installed-game service. A completed
RAEON distribution must carry the execution components and data it needs; the player must
not clone a repository, contact GitHub or have a developer checkout next to the game.

The same distinction applies to the developer handoff: after the declared dependency
bundle is acquired, its supported compile/verify/run path must work offline from that
bundle. Do not promise a clean source checkout can build offline before its dependency
assets are provided.

## 2. Required Pass-2 packaging work

Extend the existing packaging command, not a new parallel release tree. Include the new
RAEON `.gen` sources, manifest/schema inputs, derived runtime catalog and all catalog/QMO
records actually consumed by Pass 2. Include required generic Horizon binding changes,
exact supported compiler/runtime slice, native dependencies and notices. List deferred
Pass-3 data explicitly if not yet a runtime dependency; never leave a hidden path back to
a source checkout.

Keep `_bricked` untouched. Vendor a hash-locked subset into the designated build/SDK
bundle or resolve the already packaged subset; preserve the origin/commit/notices. Do
not copy 4.3 GB to inflate size or duplicate the canonical language development tree.
All maintained locks/manifests/build code belong in `_raeon`. Required large artifacts
follow its existing LFS/release policy, not ad hoc committed cache directories.

The current packaging is a Windows x64 CPython 3.12 reference handoff with offline wheels,
not a signed native app containing a Python interpreter. Retain an explicit Python
prerequisite for this pass unless an actual interpreter installer is added and tested.
Native iOS/Android/Windows app bundles and their SDKs remain later Port work. Do not label
an untested platform as supported merely because the wire format is portable.

## 3. Isolation acceptance procedure

1. Package from an identified clean committed `_raeon` source revision; include source,
   compiled-bytecode and data hashes in the inventory. Exclude caches before hashing.
2. Extract into a fresh path with spaces, outside both repositories. Reject duplicate ZIP
   members, absolute/parent traversal paths and conflicting files between paired archives.
3. Run in a process/environment that cannot access the original `_bricked` checkout.
   Clear `RAEON_GENESIS_UPSTREAM`, developer `PYTHONPATH`, `PYTHONHOME` and inherited
   site-package shortcuts. Do not rename/delete a user's real checkout to fake isolation.
4. Install from included wheels with package-index access disabled. This alone is not
   proof of zero network access: independently deny/monitor network connects and Git
   subprocess invocation for build/run, recording the enforcement method and its limits.
5. Ensure no `_bricked` sibling checkout and no usable Git command is required. SDK files
   inside the extracted bundle may retain historical upstream paths/names; that is not
   an external dependency. Historical URLs and commit hashes may remain in provenance.
6. Invoke the supported compiled-source rebuild/verification path using only the bundle,
   then both previous demos and the new Pass-2 demo, tests and checkpoint/restart.
7. Verify every runtime file read is satisfied by bundle, configured writable state or
   declared interpreter/system prerequisites. Delete/disable only the **temporary test**
   copy of an essential dependency to prove missing data produces a clear dependency
   failure, not an automatic network fetch.
8. Compare rebuilt bytecode/data hashes at a different physical path. Leave normal
   runtime startup offline and fail clearly on a missing/mismatched packaged dependency.

Build/packaging provenance commands in a developer checkout may inspect Git. Installed
build/verify/run and game startup must not call Git or fetch a source repository.
Separate these entry points rather than disabling the repository audit.

## 4. Evidence

Record host/Python versions, source commit, bundle hash, files manifest, dependency
origins, exact commands, exit codes, network/Git isolation method, required runtime file
closure, and supported/NOT_RUN targets. A test that merely removes an environment
variable or sets `PIP_NO_INDEX` is not enough to assert total offline isolation.

The developer-facing application/Horizon package and Hypervisor package may remain two
matching distributions, provided the combined dependency closure is documented and
verified. The Diplomatic Pouch is not either of those runtime packages.
