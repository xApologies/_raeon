# RAEON Pass 2 — Vera source review and focused reproduction

Date: 2026-09-30  
Repository: `xApologies/_raeon`  
Reviewed branch: `codex/raeon-pass-02`  
Reviewed HEAD: `8a20961b97b0bbb6e2e257d3c3ff62992ea6d839`  
Pass-1 base: `23ebfc3be3a4e6ae4883793bfc99b1dbfae67bf8`  
Disposition: **IMPLEMENTATION PRESENT; PROJECTION CORRECTION REQUIRED BEFORE CLEAN ACCEPTANCE.**

This review does not erase the implementation, restart Pass 2, change gameplay rules,
or claim to have independently rerun the complete Windows reference suite. No remote
files, branches, commits or pull requests were changed by this review.

## 1. Evidence classes

**Directly checked through the live GitHub connector:** the remote Pass-2 branch and
HEAD, its comparison to the Pass-1 base, current main, committed receipt, source changes,
representative Genesis handlers, native/boundary adapters, collection policy/operations,
projection implementations, transaction/adversarial tests, acceptance aggregation and
offline-isolation implementation.

**Reported in the committed Codex receipt, not independently rerun here:** 83/83 Pass-2
requirements, 74/74 runtime requirements, 62 local tests, 575 upstream checks, seven
validators, 211 repository regressions, 17 gameplay-design tests, 36 compiled Genesis
sources and the fresh Windows offline installation/build/run results.

**Independently executed here:** five focused projection tests using the exact fetched
projection function bodies with a small synthetic backend fixture. Two positive controls
passed; three required privacy assertions failed. Transcript and exit status are included.
These tests do not invoke Genesis/GVM, the complete Horizon or the Windows environment.
An optional loader permits the same tests to import the actual methods from a trusted
local `_raeon` checkout instead of using the included excerpts.

A full checkout/test rerun was not available: a container Git clone attempt failed with
`Could not resolve host: github.com`. Connector source reads succeeded. This is a
limitation of this review environment, not evidence of a repository/build failure.

## 2. Repository and delivered scope

The remote branch exists at the reviewed SHA. Compared with the completed Pass-1 base,
it is four commits ahead and zero behind, with 63 changed files: 48 additions and 15
modifications, with no deletions/renames in the comparison. Main remains at
`69a0030805b8c3858c877a514e2f50644421115a`. The receipt identifies implementation/archive
commit `f5c380deccb1297f455a599004b159706b39735c`; the later closing commit records delivery.

The change set contains actual `.gen` application handlers, not only documentation:
inventory initialization, shuffle, draw, FG commitment, structural Prime binding,
retirement/support retirement, six recovery profiles, bounded inspection/reordering,
batch transfer and additional Configuration Spaces. Native helper programs instantiate,
relate and transport Geometrics. Section-14 value programs support integer checks.

The unchanged Hypervisor remains the translation fence. The Horizon's generic host
bindings now provide parameterized collection execution. The `.gen` handler attributes
supply source-linked application policy; the binding executes bounded collection
algorithms and invokes actual native instantiation/transport units. This is still the
host-reference execution architecture, not a fully self-hosted/native-device release.

### Dynamic spaces are represented correctly for the Pass-2 scope

`add_configuration_space.gen` declares an extension of the existing owner's region, a
maximum of nine, and Red/Orange/Yellow/Green/Blue/Violet capacities 3/4/5/6/7/8. The
collection implementation instantiates a new space when admitted. The tests explicitly
exercise all six capacities, reject the tenth active space, preserve original identities,
and allow repeated colors. This is not a three-slot-only board.

Merge/base accounting, expiry and the complete Utility play scheduler remain separate
policy/later-pass work; no general post-merge minimum of three independent spaces is
inferred from this boot/expansion test.

### Identity and transfer implementation

The inspected source separates card catalog identity, live copy identity, immutable
native version, location/history and ordered membership. Moves invoke the native local
Rainbow Road path. Candidate collection state, grants, RNG and outcomes participate in
atomic State publication. Tests exercise source-removal rollback, duplicate requests,
stale requests, recovery order and card conservation.

Those are substantive implementation and test cases. This review does not reclassify
the entire branch as a scaffold because the projection finding below needs correction.

### Offline delivery

The committed report gives two matching 0.2.0 distributions: Horizon 17,840,560 bytes and
Hypervisor 17,293 bytes. The isolation helper explicitly intercepts network/DNS, Git and
external-file access in the trusted Python test processes; it is not merely a
`PIP_NO_INDEX` claim. The report states a missing dependency fails closed, without fetch.
I inspected this mechanism and its reported outcome, not the original ignored trace files
or a new installed run. Windows x64 CPython 3.12 remains a declared prerequisite. Native
SDK/device validation is not claimed. Upstream read-only cleanliness is likewise reported
by Codex; this review cannot inspect Codex's local `_bricked` working tree.

## 3. Confirmed finding: public-view narrowing is not preserved

**Finding:** V-P2-01  
**Priority:** fix before clean Pass-2 acceptance / before building new public presentation
on these projections.  
**Location:** `game/core/genesis_horizon/bindings/python/src/raeon_genesis_horizon/collections.py`,
`Collections.project`; compare `application.py::project` and `adapter.py::Horizon._view`.

The adapter first runs the original application projection and then passes its result
through the new live-collection projector. The first projector takes permission from
the selected manifest view (`private_owner`) and filters `private_to` relationships.
The second projector recalculates visibility from actor-level flags and finally appends
all relationships whose endpoints are visible. As a result, the second stage can broaden
the first stage's authorized output.

### A. A selected public view can regain a player's private Hand

The manifest's `public` view has `private_owner: null`. A trusted actor can have access
to their own private view while still asking the application to produce a public view.
`application.project` correctly withholds the private fields for this selection.
`Collections.project` instead uses `player_role` whenever `private_view` is true,
and can insert that player's Hand contents and catalog identities into the public output.

This is a view-narrowing defect, not a claim that a remote opponent can forge arbitrary
session authority. The trusted-session dictionary itself can be valid; the selected
public projection should still remain public.

### B. A same-actor public view can inherit an authorized private inspection

Inspection results are keyed by actor and current revision. The collection projector
adds them whenever those two match, without also requiring that the selected view is
permitted to reveal the inspection. A non-private public session for the same actor can
therefore receive the recently inspected card identities and catalog references.

The focused test uses `view_id='public'` and `private_view=False`; only the actor matches
the actor of the stored inspection. The private inspection nevertheless appears.

### C. Filtered private relationships are re-added

The original projector removes `private_to` edges from public output. The final collection
edge loop checks only visible endpoints and duplication. Since the player and empty
container objects are publicly visible, it appends the filtered `private_to` edges again.
This leaks protected relationship metadata rather than, by itself, a hidden card list.

### Executed results

Command: `python -B -m unittest -v test_projection_privacy`

| Probe | Actual result |
|---|---|
| Owner-private view exposes own Hand, not opponent Hand | PASS |
| Ordinary public view without inspection hides both Hands | PASS |
| Public view remains public for private-capable actor | FAIL |
| Public non-private view excludes same-actor private inspection | FAIL |
| Public view does not restore filtered `private_to` edges | FAIL |

Run: 5; passed: 2; failed: 3; exit: 1. Assertions express the required property and are
not inverted or marked expectedFailure to manufacture green results.

The existing nonempty private-view tests check owner versus opponent. That is useful,
but it does not test these same-actor public/private-view combinations. Passing the
existing 83-case mapped suite does not resolve these counterexamples.

## 4. Required correction and proof

Use one consistent effective view authorization through both projection layers. General
actor capability may authorize access to a private view; it must not silently turn a
selected public view into that private view. Apply the same rule to inspections and
relationship aggregation. Dynamic publicly visible spaces/cards must continue to appear
when their declared visibility permits them.

Add actual production-package/Horizon/Hypervisor integration tests for both players:
public views from private-capable actors; explicit non-private public sessions after
private inspection; filtered private relationships; ordinary owner/opponent views;
reconnect and snapshot/delta paths; inspection expiry after the next semantic revision.
Do not remove public views, make Hands public or hide all dynamic objects to pass.

Keep the existing 83 cases and add the new cases as explicit additional evidence. Rerun
Pass-1/runtime regressions, repository validators, real Genesis build/verification and
fresh distribution verification. Correct only the necessary generic projection/binding
logic and its versioned integrity/provenance records. No architecture rewrite or
_bricked edit is required by this finding.

## 5. Current checkpoint

Pass 2: implemented and pushed; targeted projection fix required for clean review.
Pass 3: next planned work after that fix is reproduced on the real branch and checked.
Whole game: PREPRODUCTION. Native ports, full Utility play/timing, field topology/pose,
Prime/color combat and complete match rules remain outside this Pass-2 completion scope.

All source findings apply to the pinned reviewed SHA; inspect newer commits rather than
rolling back newer work. This audit ZIP is evidence/handoff material, not a replacement
implementation tree.
