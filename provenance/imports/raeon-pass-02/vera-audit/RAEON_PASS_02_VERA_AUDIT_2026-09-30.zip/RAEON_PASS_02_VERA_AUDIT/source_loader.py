"""Optional loading of the actual checked-out projection modules for these probes.

Only the dependency services unused by projection are stubbed. Both production
projection implementations are imported from their real files. This loader is
not a substitute for the requested full Genesis/Hypervisor integration tests.
Run only against trusted repository code.
"""
from pathlib import Path
import hashlib
import importlib.util
import sys
import types
from projection_excerpts import digest


def load_production(repo):
    root = Path(repo).resolve()
    base = root / 'game/core/genesis_horizon/bindings/python/src/raeon_genesis_horizon'
    namespace = '_raeon_projection_review'
    package = types.ModuleType(namespace)
    package.__path__ = [str(base)]
    sys.modules[namespace] = package
    toolchain = types.ModuleType(namespace + '.toolchain')
    toolchain.digest = digest
    import json
    toolchain.canonical = lambda v: json.dumps(v, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf8')
    toolchain.file_hash = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    sys.modules[toolchain.__name__] = toolchain
    values = types.ModuleType(namespace + '.values')
    class UnusedIntegerInterpreter:
        def __init__(self, *a, **kw):
            raise AssertionError('Projection probes must not invoke value execution.')
    values.IntegerInterpreter = UnusedIntegerInterpreter
    sys.modules[values.__name__] = values
    loaded = {}
    for module in ['application', 'collections']:
        path = base / (module + '.py')
        if not path.is_file():
            raise FileNotFoundError(path)
        name = namespace + '.' + module
        spec = importlib.util.spec_from_file_location(name, path)
        obj = importlib.util.module_from_spec(spec)
        sys.modules[name] = obj
        spec.loader.exec_module(obj)
        loaded[module] = obj
    return loaded['application'].project, loaded['collections'].Collections
