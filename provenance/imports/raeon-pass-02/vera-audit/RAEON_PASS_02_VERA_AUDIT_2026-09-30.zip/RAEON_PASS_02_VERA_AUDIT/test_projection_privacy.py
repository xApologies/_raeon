"""Focused projection invariants: actual method bodies with a small backend fixture.

This does not execute Genesis/GVM, the full Hypervisor, or the Windows suite.
Against the inspected source, the two controls pass and three privacy checks fail.
These expected invariants intentionally remain normal failing assertions, not
expectedFailure tests or inverted assertions that could be mistaken for a pass.
"""
import copy
import json
import os
import unittest
from types import SimpleNamespace
from projection_excerpts import project, CollectionsExcerpt

if os.environ.get("RAEON_AUDIT_SOURCE_ROOT"):
    from source_loader import load_production
    project, CollectionsExcerpt = load_production(os.environ["RAEON_AUDIT_SOURCE_ROOT"])


class ProjectionPrivacy(unittest.TestCase):
    def setUp(self):
        resources, bindings = {}, {}
        for name, kind, owner in [
            ('player_1', 'PLAYER', None), ('player_2', 'PLAYER', None),
            ('player_1_hand', 'HAND', 'player_1'),
            ('player_2_hand', 'HAND', 'player_2'),
            ('player_1_deck', 'DECK', 'player_1'),
        ]:
            bindings[name] = 'res:' + name
            resources[bindings[name]] = {'payload': {'identity': 'id:' + name,
                'semantic': {'id': name, 'kind': kind, 'owner': owner,
                             'public': {}, 'private': {'contents': []} if kind == 'HAND' else {}}}}
        relations = []
        for player in ['player_1', 'player_2']:
            key = 'edge:' + player
            resources[key] = {'payload': {'source': 'id:' + player + '_hand',
                                           'target': 'id:' + player,
                                           'relation': 'private_to'}}
            relations.append(key)
        cards = {}
        collections = {}
        for player, catalog in [('player_1', 'FG-001'), ('player_2', 'FG-002')]:
            identity = 'card:' + player
            cards[identity] = {'owner': player, 'catalog': catalog,
                              'category': 'Field Generator'}
            collections[player + '_hand'] = {'owner': player, 'kind': 'HAND',
                                              'members': [identity]}
        cards['card:deck_top'] = {'owner': 'player_1', 'catalog': 'FG-003', 'category': 'Field Generator'}
        collections['player_1_deck'] = {'owner': 'player_1', 'kind': 'DECK', 'members': ['card:deck_top']}
        values = {'cards': cards, 'collections': collections, 'inspections': {}}
        self.b = SimpleNamespace(bindings=bindings, resources=resources,
                                 relations=relations, application_values=values)
        self.manifest = {'views': {
            'public': {'objects': list(bindings), 'private_owner': None},
            'player_1': {'objects': list(bindings), 'private_owner': 'player_1'},
            'player_2': {'objects': list(bindings), 'private_owner': 'player_2'},
        }}
        self.service = object.__new__(CollectionsExcerpt)
        self.service.manifest = self.manifest
        self.service.b = self.b
        self.service.h = SimpleNamespace(_state={'revision': 10})
        self.service.config = {'item_kind': 'CARD', 'populated_states': {},
                               'containers': {'HAND': {'visibility': 'owner'}, 'DECK': {'visibility': 'count'}}}

    def authority(self, view_id='public', private=False, actor='viewer'):
        return {'view_id': view_id, 'private_view': private,
                'player_role': 'player_1', 'actor': actor, 'application_id': 'raeon'}

    def render(self, authority):
        return self.service.project(project(self.b, self.manifest, authority), authority)

    def test_control_owner_view_exposes_only_own_hand(self):
        result = self.render(self.authority('player_1', True, 'alice'))
        self.assertIn('card:player_1', json.dumps(result))
        self.assertNotIn('card:player_2', json.dumps(result))
        self.assertNotIn('card:deck_top', json.dumps(result))

    def test_control_public_hides_cards_without_inspection(self):
        result = self.render(self.authority())
        self.assertNotIn('card:player_1', json.dumps(result))
        self.assertNotIn('card:player_2', json.dumps(result))
        self.assertNotIn('card:deck_top', json.dumps(result))

    def test_public_view_must_stay_public_for_private_capable_actor(self):
        authority = self.authority('public', True, 'alice')
        base = project(self.b, self.manifest, authority)
        self.assertNotIn('card:player_1', json.dumps(base))
        result = self.service.project(copy.deepcopy(base), authority)
        self.assertNotIn('card:player_1', json.dumps(result),
                         'Collection projection widened the selected public view.')

    def test_public_view_must_not_export_private_inspection(self):
        self.b.application_values['inspections']['alice'] = {
            'revision': 10, 'items': ['card:deck_top']}
        # Same actor uses an explicitly public, non-private session.
        result = self.render(self.authority('public', False, 'alice'))
        self.assertNotIn('inspection', result,
                         'Inspection is actor-bound but not authorized for this view.')

    def test_public_view_must_not_restore_private_to_edges(self):
        authority = self.authority()
        base = project(self.b, self.manifest, authority)
        self.assertEqual(base['relations'], [])
        result = self.service.project(copy.deepcopy(base), authority)
        self.assertEqual(result['relations'], [],
                         'Final edge aggregation restored filtered private_to edges.')


if __name__ == '__main__':
    unittest.main(verbosity=2)
