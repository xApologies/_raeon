# RAEON Pass-2 audit evidence

Read `AUDIT.md` first. This package contains a source review, focused failing privacy
probes, and an execution order for the targeted correction. It does not change Git.

## Reproduce the reviewed method-body behavior

With a local Python interpreter, from this directory:

    python -B -m unittest -v test_projection_privacy

At the reviewed source, the expected *observed* outcome is two controls passing and
three privacy assertions failing (exit 1). That is evidence of the problem, not a clean
implementation pass.

## Run the same probes against real checked-out methods

Set `RAEON_AUDIT_SOURCE_ROOT` to your `_raeon` checkout, then run the same command.
For example, in PowerShell:

    $env:RAEON_AUDIT_SOURCE_ROOT = 'C:\path\to\_raeon'
    python -B -m unittest -v test_projection_privacy

`source_loader.py` imports actual application.py and collections.py. Only unused
compiler/value services are replaced for these projection-only tests. It does not
exercise the native runtime. The full integration regressions requested in
`CODEX_CORRECTION.md` remain necessary.

The default excerpt mode is an immutable reproduction of the reviewed source; it will
continue failing after a repository correction. Use live-source mode or real integration
tests to verify the corrected repository, not edited excerpts.

## Hand off the correction

Give this ZIP to the existing Codex task and say:

> Execute CODEX_CORRECTION.md. Preserve Pass 2 and fix the audited projection cases.

No upstream edits, reset, source-tree replacement, or merge to main is requested.
