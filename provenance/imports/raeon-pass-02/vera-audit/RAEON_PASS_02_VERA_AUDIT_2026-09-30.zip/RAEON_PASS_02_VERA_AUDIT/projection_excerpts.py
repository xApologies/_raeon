"""Unmodified projection function bodies transcribed from pinned repository source.

Commit: 8a20961b97b0bbb6e2e257d3c3ff62992ea6d839
application.py: project; collections.py: Collections.project.
Only imports, the minimal class wrapper and its state property are supplied here.
This module is NOT the complete Horizon/runtime; it supports a source-level probe.
"""
import copy
import hashlib
import json


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     ensure_ascii=False).encode('utf8')).hexdigest()


def project(backend, manifest, authority):
    view = manifest['views'].get(authority.get('view_id'))
    if not isinstance(view, dict):
        raise ValueError('AUTHORITY_DENIED')
    owner = view['private_owner']
    if owner is not None and (authority.get('player_role') != owner or not authority.get('private_view')):
        raise ValueError('AUTHORITY_DENIED')
    objects = {}
    for name in view['objects']:
        payload = backend.resources[backend.bindings[name]]['payload']
        semantic = payload['semantic']
        fields = dict(semantic['public'])
        if owner is not None and owner == semantic['owner']:
            fields.update(semantic['private'])
        objects[name] = {'identity': payload['identity'], 'semantic_id': semantic['id'],
                         'kind': semantic['kind'], 'owner': semantic['owner'], 'fields': fields}
    visible = {o['identity'] for o in objects.values()}
    owner_id = objects[owner]['identity'] if owner in objects else None
    relations = []
    for ref in backend.relations:
        relation = backend.resources[ref]['payload']
        if relation['source'] in visible and relation['target'] in visible:
            if relation['relation'] != 'private_to' or relation['target'] == owner_id:
                relations.append(dict(relation))
    # Caller detaches the entire value. Never expose native resource dictionaries.
    return {'objects': objects, 'relations': relations}


class CollectionsExcerpt:
    @property
    def state(self):
        return self.b.application_values

    def project(self, view, authority):
        owner = authority.get('player_role') if authority.get('private_view') else None
        for name, collection in self.state['collections'].items():
            if name not in view['objects']:
                payload = self.b.resources[self.b.bindings[name]]['payload']
                semantic = payload['semantic']
                view['objects'][name] = {'identity': payload['identity'], 'semantic_id': semantic['id'],
                                         'kind': semantic['kind'], 'owner': semantic['owner'],
                                         'fields': copy.deepcopy(semantic['public'])}
            fields = view['objects'][name]['fields']
            fields.pop('contents', None)
            fields.pop('order', None)
            fields['count'] = len(collection['members'])
            fields['state'] = self.config['populated_states'].get(collection['kind'], 'POPULATED') if collection['members'] else 'EMPTY'
            rule = self.config['containers'][collection['kind']]['visibility']
            visible = rule == 'public' or (rule == 'owner' and owner == collection['owner'])
            if visible:
                fields['contents'] = list(collection['members'])
                for identity in collection['members']:
                    if identity in self.state['cards']:
                        card = self.state['cards'][identity]
                        view['objects'][identity] = {'identity': identity, 'semantic_id': identity,
                            'kind': self.config['item_kind'], 'owner': card['owner'],
                            'fields': {'catalog': card['catalog'], 'category': card['category'], 'location': name}}
            if 'occupant' in fields:
                fields['occupant'] = collection['members'][0] if collection['members'] else None
        inspection = self.state['inspections'].get(authority['actor'])
        if inspection and inspection['revision'] == self.h._state['revision']:
            view['inspection'] = [{'identity': i, 'catalog': self.state['cards'][i]['catalog']} for i in inspection['items']]
        visible = {obj['identity'] for obj in view['objects'].values()}
        existing = {digest(edge) for edge in view['relations']}
        for ref in self.b.relations:
            edge = self.b.resources[ref]['payload']
            if edge['source'] in visible and edge['target'] in visible and digest(edge) not in existing:
                view['relations'].append(copy.deepcopy(edge))
        return view
