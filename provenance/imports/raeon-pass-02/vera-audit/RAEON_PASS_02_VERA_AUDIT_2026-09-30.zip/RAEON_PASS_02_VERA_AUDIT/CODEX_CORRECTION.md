# Codex: targeted Pass-2 projection correction

Continue the existing `xApologies/_raeon` Pass-2 work; do not restart Pass 2 or redesign
the machine. Write only to `_raeon`. Keep `_bricked` read-only and main unmerged.

Read AUDIT.md, then reproduce V-P2-01 against the actual production RAEON package at the
current branch, preserving newer valid work. Reviewed baseline:
`8a20961b97b0bbb6e2e257d3c3ff62992ea6d839` on `codex/raeon-pass-02`.

The included excerpt probes show three failures in the same live-projection feature.
They are small source-level reproductions, not full Genesis/GVM tests. Prefer adding
corresponding real integration tests using the existing CardFixture/Hypervisor paths.
The optional source_loader can also run the focused probes against your checked-out
application.py and collections.py without importing their full native dependencies.

Reproduce and correct:
1. `view_id=public` must not reveal Hand cards even if the actor also has private-view
   capability and a player_role. View-specific permission must be preserved end-to-end.
2. After private INSPECT_TOP, a public session for the same actor must not receive the
   private inspection. Scope inspections to authorized view/owner/application context
   as well as actor and revision; maintain normal private inspection and expiry behavior.
3. The final live-relationship merge must not restore `private_to` edges removed by the
   earlier application projection. Use the same effective visibility policy throughout.

Maintain dynamic Configuration Spaces and admitted public geometry. Do not delete the
public view, change accepted hidden-information rules, or disable live updates as a fix.
Do not relocate gameplay into the Hypervisor or modify Genesis source merely to disguise
what is a host-reference projection issue.

Verify with both player roles, owner-private/opponent/public views, trusted actor with
multiple permitted views, non-private public session after inspection, HELLO/SNAPSHOT,
SYNC_REQUEST, appropriate DELTA paths, reconnect, and inspection expiry at a later
semantic revision. No semantic-state mutation may occur from observation.

Retain all existing Pass-2, Pass-1 and runtime tests and their original denominators;
add the regression cases separately. Run the established compiler/runtime/repository
checks and fresh distribution verification. Add an accurately scoped correction receipt,
update source-integrity records through normal provenance conventions, commit coherent
changes and push the authorized task branch. Report actual local/remote SHAs, test
results and scope. Do not merge main or claim device-level execution.

Keep the same runtime architecture. This is a focused fix to finished implementation
work, not a request for a new framework or another planning package.
